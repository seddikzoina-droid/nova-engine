// اختبارات نواة المحرك (بدون واجهة): الرياضيات، الحفظ والتحميل، الفيزياء، التسلسل الهرمي، السكربتات
#include <cmath>
#include <cstdio>

#include "core/Input.h"
#include "scene/Scene.h"

using namespace nova;

static int g_failed = 0;
#define CHECK(cond)                                                              \
    do {                                                                         \
        if (!(cond)) {                                                           \
            std::printf("FAIL %s:%d  %s\n", __FILE__, __LINE__, #cond);          \
            ++g_failed;                                                          \
        }                                                                        \
    } while (0)

static bool Near(float a, float b, float eps = 1e-3f) { return std::fabs(a - b) < eps; }
static bool NearV(const Vec3& a, const Vec3& b, float eps = 1e-3f) {
    return Near(a.x, b.x, eps) && Near(a.y, b.y, eps) && Near(a.z, b.z, eps);
}

static void TestMath() {
    Mat4 m = Mat4::TRS(Vec3(1, 2, 3), Vec3(30, 40, 50), Vec3(1, 2, 3));
    Mat4 id = m * m.Inverse();
    for (int c = 0; c < 4; ++c)
        for (int r = 0; r < 4; ++r) CHECK(Near(id.m[c * 4 + r], c == r ? 1.0f : 0.0f));

    Vec3 p, r, s;
    m.Decompose(p, r, s);
    CHECK(NearV(p, Vec3(1, 2, 3)));
    CHECK(NearV(r, Vec3(30, 40, 50), 0.05f));
    CHECK(NearV(s, Vec3(1, 2, 3)));

    // الأمام (-Z) بعد تدوير 90 درجة حول Y يصبح -X
    Vec3 f = Mat4::RotateY(90).TransformDir(Vec3(0, 0, -1));
    CHECK(NearV(f, Vec3(-1, 0, 0)));

    // المنظور: نقطة أمام الكاميرا تقع داخل مكعب القص
    Mat4 vp = Mat4::Perspective(60, 1.5f, 0.1f, 100.f) * Mat4::LookAt(Vec3(0, 0, 5), Vec3(0, 0, 0), Vec3(0, 1, 0));
    Vec3 ndc = vp.TransformPointW(Vec3(0, 0, 0));
    CHECK(Near(ndc.x, 0) && Near(ndc.y, 0) && ndc.z > -1 && ndc.z < 1);
}

static void TestHierarchyAndSerialization() {
    Scene sc;
    Entity* a = sc.Create("Parent A");
    a->transform.position = Vec3(10, 0, 0);
    a->mesh = MeshRenderer{};
    a->mesh->texture = "assets/my tex.png";
    Entity* b = sc.Create("Child B", a->id);
    b->transform.position = Vec3(1, 0, 0);
    b->light = Light{};
    b->light->type = LightType::Point;
    Entity* c = sc.Create("Cam");
    c->camera = Camera{};
    c->camera->orthographic = true;
    Script* sp = c->AddScript("Spinner");
    CHECK(sp != nullptr);
    for (auto& pr : sp->props)
        if (pr.name == "speedY") *pr.value = 123.5f;
    c->rigidbody = RigidBody{};
    c->collider = BoxCollider{};
    c->sprite = SpriteRenderer{};

    CHECK(NearV(sc.WorldMatrix(*b).TransformPoint(Vec3(0, 0, 0)), Vec3(11, 0, 0)));

    // إعادة الربط تحافظ على موضع العالم
    CHECK(sc.SetParent(b->id, 0));
    CHECK(NearV(b->transform.position, Vec3(11, 0, 0)));
    CHECK(sc.SetParent(b->id, a->id));
    CHECK(NearV(b->transform.position, Vec3(1, 0, 0)));
    CHECK(!sc.SetParent(a->id, b->id));  // حلقة ممنوعة

    std::string s1 = sc.Serialize();
    Scene sc2;
    CHECK(sc2.Deserialize(s1));
    CHECK(sc2.Serialize() == s1);
    CHECK(sc2.Entities().size() == 3);
    Entity* a2 = sc2.FindByName("Parent A");
    CHECK(a2 && a2->mesh && a2->mesh->texture == "assets/my tex.png");
    CHECK(a2 && a2->children.size() == 1);
    Entity* c2 = sc2.FindByName("Cam");
    CHECK(c2 && c2->camera && c2->camera->orthographic);
    CHECK(c2 && c2->scripts.size() == 1);
    if (c2 && !c2->scripts.empty())
        for (auto& pr : c2->scripts[0]->props)
            if (pr.name == "speedY") CHECK(Near(*pr.value, 123.5f));

    CHECK(!sc2.Deserialize("garbage"));
    CHECK(sc2.Entities().size() == 3);  // المشهد لم يتغير عند الفشل

    // النسخ مع الأبناء
    EntityId dup = sc.Duplicate(a->id);
    CHECK(dup != 0 && sc.Entities().size() == 5);
    CHECK(sc.Find(dup)->children.size() == 1);

    // الحذف المتسلسل
    sc.Destroy(a->id);
    CHECK(sc.Find(a->id) == nullptr && sc.Find(b->id) == nullptr);
    CHECK(sc.Entities().size() == 3);
}

static void TestPhysicsAndScripts() {
    Scene sc;
    Entity* floor = sc.Create("Floor");
    floor->collider = BoxCollider{};
    floor->collider->size = Vec3(1, 0.2f, 1);
    floor->transform.scale = Vec3(20, 1, 20);
    floor->transform.position = Vec3(0, -0.1f, 0);  // سطح الأرض عند y = 0

    Entity* cube = sc.Create("Player");
    cube->transform.position = Vec3(0, 3, 0);
    cube->rigidbody = RigidBody{};
    cube->collider = BoxCollider{};
    Entity* spin = sc.Create("Spin");
    spin->AddScript("Spinner");

    sc.Start();
    for (int i = 0; i < 180; ++i) sc.Update(1.0f / 60.0f);
    CHECK(Near(cube->transform.position.y, 0.5f, 0.05f));
    CHECK(cube->rigidbody->grounded);
    CHECK(Near(spin->transform.rotation.y, 135.0f, 0.5f));  // 45 درجة/ث × 3 ث

    // تحكم اللاعب: الضغط على D يحرّك على X، والمسافة تقفز
    Input::Down(Key::D) = true;
    float x0 = cube->transform.position.x;
    cube->AddScript("PlayerController");
    for (int i = 0; i < 30; ++i) sc.Update(1.0f / 60.0f);
    CHECK(cube->transform.position.x > x0 + 1.5f);
    Input::Down(Key::D) = false;
    Input::Down(Key::Space) = true;
    sc.Update(1.0f / 60.0f);
    CHECK(cube->transform.position.y > 0.5f);
    Input::Down(Key::Space) = false;

    // الكاميرا الرئيسية
    CHECK(sc.MainCamera() == nullptr);
    Entity* cam = sc.Create("Cam");
    cam->camera = Camera{};
    CHECK(sc.MainCamera() == cam);
    cam->active = false;
    CHECK(sc.MainCamera() == nullptr);
}

// مشهد 2D التجريبي: يُحمَّل ويعمل، واللاعب يقف على الأرض ويقفز
static void TestDemo2D() {
    Scene sc;
    CHECK(sc.LoadFromFile("assets/demo_2d.nova"));
    Entity* p = sc.FindByName("Player");
    CHECK(p && p->sprite && p->rigidbody && p->rigidbody->freezeZ && !p->scripts.empty());
    if (!p) return;
    sc.Start();
    for (int i = 0; i < 120; ++i) sc.Update(1.0f / 60.0f);
    CHECK(p->rigidbody->grounded);
    CHECK(Near(p->transform.position.y, 0.0f, 0.05f));  // الأرض: سطحها عند y = -0.5، واللاعب نصفه 0.5
    Input::Down(Key::Space) = true;
    sc.Update(1.0f / 60.0f);
    Input::Down(Key::Space) = false;
    CHECK(p->transform.position.y > 0.0f);
    CHECK(Near(p->transform.position.z, 0.0f));
}

int main() {
    TestMath();
    TestDemo2D();
    TestHierarchyAndSerialization();
    TestPhysicsAndScripts();
    if (g_failed == 0) std::printf("ALL TESTS PASSED\n");
    else std::printf("%d CHECK(S) FAILED\n", g_failed);
    return g_failed == 0 ? 0 : 1;
}
