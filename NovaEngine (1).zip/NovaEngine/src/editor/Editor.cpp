#include "editor/Editor.h"

#include <imgui.h>
#include <imgui_internal.h>
#include <ImGuizmo.h>  // يجب أن يأتي بعد imgui.h

#include <algorithm>
#include <cctype>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <initializer_list>

#include "core/Input.h"
#include "core/Log.h"
#include "core/Touch.h"
#include "platform/Platform.h"
#include "render/Texture.h"

namespace fs = std::filesystem;

namespace nova {

namespace {

bool HasExt(const std::string& s, std::initializer_list<const char*> exts) {
    std::string l = s;
    std::transform(l.begin(), l.end(), l.begin(), [](unsigned char c) { return static_cast<char>(std::tolower(c)); });
    for (const char* e : exts) {
        size_t n = std::strlen(e);
        if (l.size() >= n && l.compare(l.size() - n, n, e) == 0) return true;
    }
    return false;
}

void ScanAssets(std::vector<std::string>& out) {
    out.clear();
    std::error_code ec;
    if (!fs::exists("assets", ec)) return;
    for (auto it = fs::recursive_directory_iterator("assets", fs::directory_options::skip_permission_denied, ec);
         !ec && it != fs::recursive_directory_iterator(); it.increment(ec)) {
        std::error_code ec2;
        if (it->is_regular_file(ec2)) out.push_back(it->path().generic_string());
    }
    std::sort(out.begin(), out.end());
}

}  // namespace

// ====================================================================== setup

Editor::Editor() {
    mobile = Platform::IsMobile();
    std::error_code ec;
    fs::create_directories("assets", ec);
    if (mobile && LoadSession()) {
        // استُعيدت الجلسة السابقة
    } else {
        BuildDemoScene();
    }
    if (mobile) Log::Info("Nova Engine ready. Use the tabs at the bottom. Play opens the Game tab with an on-screen joystick.");
    else Log::Info("Nova Engine ready. Press Play, click the Game view, then use WASD / arrows and Space.");
}

Editor::~Editor() { ReleaseTextures(); }

void Editor::SaveSession() {
    std::error_code ec;
    std::string text = playing ? playSnapshot : scene.Serialize();  // أثناء التشغيل نحفظ حالة التحرير لا حالة اللعب
    std::ofstream f("session.nova", std::ios::binary);
    if (f) f << text;
    std::ofstream p("session.path", std::ios::binary);
    if (p) p << currentPath;
}

bool Editor::LoadSession() {
    std::error_code ec;
    if (!fs::exists("session.nova", ec)) return false;
    if (!scene.LoadFromFile("session.nova")) return false;
    std::ifstream f("session.path");
    std::string p;
    if (std::getline(f, p) && !p.empty()) currentPath = p;
    selected = 0;
    lastSnapshot = scene.Serialize();
    undoStack.clear();
    redoStack.clear();
    Log::Info("Restored your last session");
    return true;
}

void Editor::BuildDemoScene() {
    scene.Clear();
    selected = 0;

    Entity* cam = scene.Create("Main Camera");
    cam->camera = Camera{};
    cam->transform.position = Vec3(0, 6, 9);
    cam->transform.rotation = Vec3(-30, 0, 0);
    cam->AddScript("CameraFollow");

    Entity* sun = scene.Create("Directional Light");
    sun->light = Light{};
    sun->light->intensity = 0.9f;
    sun->transform.rotation = Vec3(-50, -30, 0);

    Entity* floor = scene.Create("Floor");
    floor->mesh = MeshRenderer{};
    floor->mesh->mesh = MeshType::Plane;
    floor->mesh->color = Vec3(0.35f, 0.5f, 0.38f);
    floor->transform.scale = Vec3(30, 1, 30);
    BoxCollider fc;
    fc.size = Vec3(1, 0.2f, 1);
    fc.center = Vec3(0, -0.1f, 0);
    floor->collider = fc;

    Entity* player = scene.Create("Player");
    player->mesh = MeshRenderer{};
    player->mesh->mesh = MeshType::Sphere;
    player->mesh->color = Vec3(1.0f, 0.55f, 0.15f);
    player->transform.position = Vec3(0, 2, 0);
    player->rigidbody = RigidBody{};
    player->collider = BoxCollider{};
    player->AddScript("PlayerController");

    Entity* block = scene.Create("Block");
    block->mesh = MeshRenderer{};
    block->mesh->color = Vec3(0.6f, 0.6f, 0.65f);
    block->transform.position = Vec3(3, 0.5f, -2);
    block->collider = BoxCollider{};

    Entity* spin = scene.Create("Spinning Cube");
    spin->mesh = MeshRenderer{};
    spin->mesh->color = Vec3(0.25f, 0.5f, 0.95f);
    spin->transform.position = Vec3(-3, 1.5f, -2);
    spin->AddScript("Spinner");

    lastSnapshot = scene.Serialize();
    undoStack.clear();
    redoStack.clear();
}

void Editor::NewScene() {
    if (playing) Stop();
    BuildDemoScene();
    currentPath = "assets/untitled.nova";
}

void Editor::OpenScene(const std::string& path) {
    if (playing) Stop();
    if (scene.LoadFromFile(path)) {
        currentPath = path;
        selected = 0;
        lastSnapshot = scene.Serialize();
        undoStack.clear();
        redoStack.clear();
        Log::Info("Opened scene: " + path);
    }
}

void Editor::SaveScene(const std::string& path) {
    if (playing) {
        Log::Warn("Stop play mode before saving.");
        return;
    }
    if (scene.SaveToFile(path)) {
        currentPath = path;
        Log::Info("Saved scene: " + path);
        lastAssetScan = -100;
    }
}

Entity* Editor::Spawn(const std::string& kind) {
    Entity* e = nullptr;
    auto prim = [&](const char* name, MeshType t) {
        e = scene.Create(name);
        e->mesh = MeshRenderer{};
        e->mesh->mesh = t;
        e->collider = BoxCollider{};
    };
    if (kind == "Empty") {
        e = scene.Create("GameObject");
    } else if (kind == "Cube") {
        prim("Cube", MeshType::Cube);
    } else if (kind == "Sphere") {
        prim("Sphere", MeshType::Sphere);
    } else if (kind == "Cylinder") {
        prim("Cylinder", MeshType::Cylinder);
    } else if (kind == "Plane") {
        prim("Plane", MeshType::Plane);
        BoxCollider bc;
        bc.size = Vec3(1, 0.2f, 1);
        bc.center = Vec3(0, -0.1f, 0);
        e->collider = bc;
    } else if (kind == "Sprite") {
        e = scene.Create("Sprite");
        e->sprite = SpriteRenderer{};
        BoxCollider bc;
        bc.size = Vec3(1, 1, 0.2f);
        e->collider = bc;
    } else if (kind == "Directional Light") {
        e = scene.Create("Directional Light");
        e->light = Light{};
        e->transform.rotation = Vec3(-50, -30, 0);
    } else if (kind == "Point Light") {
        e = scene.Create("Point Light");
        e->light = Light{};
        e->light->type = LightType::Point;
        e->transform.position = Vec3(0, 3, 0);
    } else if (kind == "Camera") {
        e = scene.Create("Camera");
        e->camera = Camera{};
        e->transform.position = Vec3(0, 3, 8);
        e->transform.rotation = Vec3(-15, 0, 0);
    } else if (kind == "Camera 2D") {
        e = scene.Create("Camera 2D");
        e->camera = Camera{};
        e->camera->orthographic = true;
        e->transform.position = Vec3(0, 0, 10);
    }
    if (e) {
        selected = e->id;
        Commit();
    }
    return e;
}

void Editor::DeleteSelected() {
    if (!selected) return;
    scene.Destroy(selected);
    selected = 0;
    Commit();
}

void Editor::DuplicateSelected() {
    if (!selected) return;
    EntityId n = scene.Duplicate(selected);
    if (n) {
        selected = n;
        Commit();
    }
}

// ====================================================================== undo / redo

void Editor::Commit() {
    if (playing) return;
    undoStack.push_back(lastSnapshot);
    if (undoStack.size() > 100) undoStack.erase(undoStack.begin());
    redoStack.clear();
    lastSnapshot = scene.Serialize();
}

void Editor::Undo() {
    if (playing || undoStack.empty()) return;
    redoStack.push_back(scene.Serialize());
    std::string s = undoStack.back();
    undoStack.pop_back();
    scene.Deserialize(s);
    lastSnapshot = s;
    if (!scene.Find(selected)) selected = 0;
}

void Editor::Redo() {
    if (playing || redoStack.empty()) return;
    undoStack.push_back(scene.Serialize());
    std::string s = redoStack.back();
    redoStack.pop_back();
    scene.Deserialize(s);
    lastSnapshot = s;
    if (!scene.Find(selected)) selected = 0;
}

// ====================================================================== play mode

void Editor::Play() {
    if (playing) return;
    playSnapshot = scene.Serialize();
    scene.Start();
    playing = true;
    paused = false;
    if (mobile) activeTab = kTabGame;
    else ImGui::SetWindowFocus("Game");
    Log::Info("Play mode started");
}

void Editor::Stop() {
    if (!playing) return;
    playing = false;
    paused = false;
    scene.Deserialize(playSnapshot);
    lastSnapshot = scene.Serialize();
    if (!scene.Find(selected)) selected = 0;
    Input::ResetAll();
    joyX = joyY = 0;
    jumpHeld = false;
    if (mobile) activeTab = kTabScene;
    Log::Info("Play mode stopped (scene restored)");
}

namespace {
// تخطيط عصا التحكم وزر القفز داخل مستطيل نافذة Game (بالبكسل)
struct VirtualLayout {
    float jx, jy, jr;  // مركز العصا ونصف قطرها
    float bx, by, br;  // مركز زر القفز ونصف قطره
};
VirtualLayout MakeLayout(const float rect[4]) {
    float u = ImGui::GetFontSize();
    VirtualLayout l;
    l.jr = u * 3.2f;
    l.jx = rect[0] + l.jr * 1.7f;
    l.jy = rect[3] - l.jr * 1.7f;
    l.br = u * 2.4f;
    l.bx = rect[2] - l.br * 2.0f;
    l.by = rect[3] - l.br * 2.2f;
    return l;
}
}  // namespace

void Editor::FeedInput() {
    // على الهاتف: اللمس الخام يحرّك العصا والزر (يدعم الإصبعين معًا)
    joyX = joyY = 0.0f;
    jumpHeld = false;
    if (mobile && playing && !paused && activeTab == kTabGame && gameRect[2] > gameRect[0]) {
        VirtualLayout l = MakeLayout(gameRect);
        const Touch& t = Touch::State();
        for (int i = 0; i < t.count; ++i) {
            float dx = t.x[i] - l.jx, dy = t.y[i] - l.jy;
            float dj = std::sqrt(dx * dx + dy * dy);
            if (dj < l.jr * 2.4f) {
                float k = 1.0f / (l.jr * 1.1f);
                joyX = Clamp(dx * k, -1.0f, 1.0f);
                joyY = Clamp(-dy * k, -1.0f, 1.0f);  // للأعلى = أمام
                float len = std::sqrt(joyX * joyX + joyY * joyY);
                if (len > 1.0f) { joyX /= len; joyY /= len; }
            }
            float bx = t.x[i] - l.bx, by = t.y[i] - l.by;
            if (std::sqrt(bx * bx + by * by) < l.br * 1.4f) jumpHeld = true;
        }
    }
    Input::AnalogH() = joyX;
    Input::AnalogV() = joyY;

    bool feed = playing && !paused && gameFocused;
    auto down = [&](ImGuiKey k) { return feed && ImGui::IsKeyDown(k); };
    Input::Down(Key::W) = down(ImGuiKey_W);
    Input::Down(Key::A) = down(ImGuiKey_A);
    Input::Down(Key::S) = down(ImGuiKey_S);
    Input::Down(Key::D) = down(ImGuiKey_D);
    Input::Down(Key::Q) = down(ImGuiKey_Q);
    Input::Down(Key::E) = down(ImGuiKey_E);
    Input::Down(Key::Space) = down(ImGuiKey_Space);
    Input::Down(Key::Left) = down(ImGuiKey_LeftArrow);
    Input::Down(Key::Right) = down(ImGuiKey_RightArrow);
    Input::Down(Key::Up) = down(ImGuiKey_UpArrow);
    Input::Down(Key::Down) = down(ImGuiKey_DownArrow);
    Input::Down(Key::Shift) = down(ImGuiKey_LeftShift);
    if (jumpHeld) Input::Down(Key::Space) = true;
}

// ====================================================================== frame

void Editor::Frame(float dt) {
    FeedInput();
    if (playing && !paused) scene.Update(std::min(dt, 0.05f));
    Shortcuts();
    if (!mobile) Dockspace();
    MainMenu();
    if (mobile) MobileTabBar();
    Hierarchy();
    Inspector();
    SceneView();
    GameView();
    Console();
    Assets();
    Dialogs();
}

// نافذة لوحة: على سطح المكتب نافذة عادية قابلة للتثبيت، وعلى الهاتف نافذة كاملة تظهر حسب التبويب المختار
bool Editor::Panel(const char* name, int tab, int extraFlags) {
    ImGuiWindowFlags flags = static_cast<ImGuiWindowFlags>(extraFlags);
    if (mobile) {
        if (tab != activeTab) return false;  // لم نستدعِ Begin، فلا يجوز استدعاء End
        ImGuiViewport* vp = ImGui::GetMainViewport();
        float top = vp->Pos.y + ImGui::GetFrameHeight();            // أسفل شريط القوائم
        float tabH = ImGui::GetFrameHeight() * 1.8f;
        ImGui::SetNextWindowPos(ImVec2(vp->Pos.x, top));
        ImGui::SetNextWindowSize(ImVec2(vp->Size.x, vp->Size.y - top - tabH));
        flags |= ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoCollapse |
                 ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_NoDocking |
                 ImGuiWindowFlags_NoBringToFrontOnFocus;
    }
    if (!ImGui::Begin(name, nullptr, flags)) {
        ImGui::End();
        return false;
    }
    return true;
}

void Editor::MobileTabBar() {
    static const char* names[kTabCount] = {"Scene", "Game", "Hierarchy", "Inspector", "Assets", "Console"};
    ImGuiViewport* vp = ImGui::GetMainViewport();
    float h = ImGui::GetFrameHeight() * 1.8f;
    ImGui::SetNextWindowPos(ImVec2(vp->Pos.x, vp->Pos.y + vp->Size.y - h));
    ImGui::SetNextWindowSize(ImVec2(vp->Size.x, h));
    ImGuiWindowFlags f = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoSavedSettings |
                         ImGuiWindowFlags_NoScrollWithMouse | ImGuiWindowFlags_NoDocking;
    ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(4, 4));
    if (ImGui::Begin("##tabbar", nullptr, f)) {
        float spacing = ImGui::GetStyle().ItemSpacing.x;
        float w = (ImGui::GetContentRegionAvail().x - spacing * (kTabCount - 1)) / kTabCount;
        for (int i = 0; i < kTabCount; ++i) {
            if (i) ImGui::SameLine();
            bool active = activeTab == i;
            if (active) ImGui::PushStyleColor(ImGuiCol_Button, ImGui::GetStyleColorVec4(ImGuiCol_ButtonActive));
            if (ImGui::Button(names[i], ImVec2(w, -1))) activeTab = i;
            if (active) ImGui::PopStyleColor();
        }
    }
    ImGui::End();
    ImGui::PopStyleVar();
}

void Editor::Shortcuts() {
    ImGuiIO& io = ImGui::GetIO();
    if (io.WantTextInput) return;
    if (io.KeyCtrl) {
        if (ImGui::IsKeyPressed(ImGuiKey_S, false)) SaveScene(currentPath);
        if (ImGui::IsKeyPressed(ImGuiKey_Z, false)) {
            if (io.KeyShift) Redo();
            else Undo();
        }
        if (ImGui::IsKeyPressed(ImGuiKey_Y, false)) Redo();
        if (ImGui::IsKeyPressed(ImGuiKey_D, false)) DuplicateSelected();
    }
    if (!playing && ImGui::IsKeyPressed(ImGuiKey_Delete, false)) DeleteSelected();
}

void Editor::Dockspace() {
    ImGuiViewport* vp = ImGui::GetMainViewport();
    ImGuiID dock = ImGui::DockSpaceOverViewport(0, vp);

    if (!layoutBuilt) {
        layoutBuilt = true;
        ImGuiDockNode* node = ImGui::DockBuilderGetNode(dock);
        if (node && !node->IsSplitNode()) {  // لا يوجد تخطيط محفوظ: ابنِ التخطيط الافتراضي
            ImGui::DockBuilderRemoveNode(dock);
            ImGui::DockBuilderAddNode(dock, ImGuiDockNodeFlags_DockSpace);
            ImGui::DockBuilderSetNodeSize(dock, vp->WorkSize);
            ImGuiID center = dock;
            ImGuiID left = ImGui::DockBuilderSplitNode(center, ImGuiDir_Left, 0.17f, nullptr, &center);
            ImGuiID right = ImGui::DockBuilderSplitNode(center, ImGuiDir_Right, 0.24f, nullptr, &center);
            ImGuiID bottom = ImGui::DockBuilderSplitNode(center, ImGuiDir_Down, 0.27f, nullptr, &center);
            ImGui::DockBuilderDockWindow("Hierarchy", left);
            ImGui::DockBuilderDockWindow("Inspector", right);
            ImGui::DockBuilderDockWindow("Console", bottom);
            ImGui::DockBuilderDockWindow("Assets", bottom);
            ImGui::DockBuilderDockWindow("Scene", center);
            ImGui::DockBuilderDockWindow("Game", center);
            ImGui::DockBuilderFinish(dock);
        }
    }
}

void Editor::MainMenu() {
    if (!ImGui::BeginMainMenuBar()) return;

    if (ImGui::BeginMenu("File")) {
        if (ImGui::MenuItem("New Scene")) NewScene();
        if (ImGui::MenuItem("Open...")) openOpenDialog = true;
        if (ImGui::MenuItem("Save", "Ctrl+S")) SaveScene(currentPath);
        if (ImGui::MenuItem("Save As...")) openSaveDialog = true;
        ImGui::Separator();
        if (ImGui::MenuItem("Exit")) Platform::RequestQuit();
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("Edit")) {
        if (ImGui::MenuItem("Undo", "Ctrl+Z", false, !undoStack.empty() && !playing)) Undo();
        if (ImGui::MenuItem("Redo", "Ctrl+Y", false, !redoStack.empty() && !playing)) Redo();
        ImGui::Separator();
        if (ImGui::MenuItem("Duplicate", "Ctrl+D", false, selected != 0)) DuplicateSelected();
        if (ImGui::MenuItem("Delete", "Del", false, selected != 0)) DeleteSelected();
        ImGui::EndMenu();
    }
    if (ImGui::BeginMenu("GameObject")) {
        if (ImGui::MenuItem("Create Empty")) Spawn("Empty");
        if (ImGui::BeginMenu("3D Object")) {
            for (const char* k : {"Cube", "Sphere", "Plane", "Cylinder"})
                if (ImGui::MenuItem(k)) Spawn(k);
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("2D Object")) {
            if (ImGui::MenuItem("Sprite")) Spawn("Sprite");
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Light")) {
            if (ImGui::MenuItem("Directional Light")) Spawn("Directional Light");
            if (ImGui::MenuItem("Point Light")) Spawn("Point Light");
            ImGui::EndMenu();
        }
        if (ImGui::BeginMenu("Camera")) {
            if (ImGui::MenuItem("Camera (3D)")) Spawn("Camera");
            if (ImGui::MenuItem("Camera (2D)")) Spawn("Camera 2D");
            ImGui::EndMenu();
        }
        ImGui::EndMenu();
    }

    // أزرار التشغيل في منتصف الشريط
    if (mobile) {
        ImGui::SameLine(0.0f, ImGui::GetFontSize());
    } else {
        float w = ImGui::GetWindowWidth();
        ImGui::SetCursorPosX(w * 0.5f - 60.0f);
    }
    if (!playing) {
        if (ImGui::Button("  Play  ")) Play();
    } else {
        if (ImGui::Button("  Stop  ")) Stop();
        ImGui::SameLine();
        if (ImGui::Button(paused ? "Resume" : "Pause")) paused = !paused;
    }
    ImGui::EndMainMenuBar();
}

// ====================================================================== hierarchy

void Editor::DrawHierarchyNode(Entity& e) {
    ImGui::PushID(static_cast<int>(e.id));
    ImGuiTreeNodeFlags f =
        ImGuiTreeNodeFlags_OpenOnArrow | ImGuiTreeNodeFlags_SpanAvailWidth | ImGuiTreeNodeFlags_DefaultOpen;
    if (e.children.empty()) f |= ImGuiTreeNodeFlags_Leaf;
    if (selected == e.id) f |= ImGuiTreeNodeFlags_Selected;

    if (!e.active) ImGui::PushStyleColor(ImGuiCol_Text, ImGui::GetStyleColorVec4(ImGuiCol_TextDisabled));
    bool open = ImGui::TreeNodeEx(e.name.empty() ? "(unnamed)" : e.name.c_str(), f);
    if (!e.active) ImGui::PopStyleColor();

    if (ImGui::IsItemClicked() && !ImGui::IsItemToggledOpen()) selected = e.id;

    if (ImGui::BeginDragDropSource()) {
        EntityId id = e.id;
        ImGui::SetDragDropPayload("ENTITY", &id, sizeof id);
        ImGui::TextUnformatted(e.name.c_str());
        ImGui::EndDragDropSource();
    }
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* p = ImGui::AcceptDragDropPayload("ENTITY")) {
            EntityId dragged = *static_cast<const EntityId*>(p->Data);
            if (scene.SetParent(dragged, e.id)) Commit();
        }
        ImGui::EndDragDropTarget();
    }
    if (ImGui::BeginPopupContextItem()) {
        selected = e.id;
        if (ImGui::MenuItem("Duplicate")) DuplicateSelected();
        if (ImGui::MenuItem("Delete")) pendingDelete = e.id;
        ImGui::EndPopup();
    }

    if (open) {
        std::vector<EntityId> kids = e.children;
        for (EntityId k : kids)
            if (Entity* c = scene.Find(k)) DrawHierarchyNode(*c);
        ImGui::TreePop();
    }
    ImGui::PopID();
}

void Editor::Hierarchy() {
    if (!Panel("Hierarchy", kTabHierarchy)) return;
    if (mobile) {
        if (ImGui::Button("+ Add")) ImGui::OpenPopup("##addobj");
        ImGui::BeginDisabled(selected == 0);
        ImGui::SameLine();
        if (ImGui::Button("Copy")) DuplicateSelected();
        ImGui::SameLine();
        if (ImGui::Button("Delete")) DeleteSelected();
        ImGui::SameLine();
        if (ImGui::Button("Edit >")) activeTab = kTabInspector;
        ImGui::EndDisabled();
        if (ImGui::BeginPopup("##addobj")) {
            for (const char* k : {"Empty", "Cube", "Sphere", "Cylinder", "Plane", "Sprite", "Directional Light",
                                  "Point Light", "Camera", "Camera 2D"})
                if (ImGui::MenuItem(k)) Spawn(k);
            ImGui::EndPopup();
        }
        ImGui::Separator();
    }
    std::vector<EntityId> roots;
    for (auto& u : scene.Entities())
        if (u->parent == 0) roots.push_back(u->id);
    for (EntityId id : roots)
        if (Entity* e = scene.Find(id)) DrawHierarchyNode(*e);

    // مساحة فارغة: إسقاط هنا يفك الارتباط بالأب، والنقر يلغي التحديد
    ImVec2 avail = ImGui::GetContentRegionAvail();
    if (avail.y < 24) avail.y = 24;
    ImGui::InvisibleButton("##hier_empty", avail);
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* p = ImGui::AcceptDragDropPayload("ENTITY")) {
            EntityId dragged = *static_cast<const EntityId*>(p->Data);
            if (scene.SetParent(dragged, 0)) Commit();
        }
        ImGui::EndDragDropTarget();
    }
    if (ImGui::IsItemClicked()) selected = 0;
    if (ImGui::BeginPopupContextItem("##hier_ctx")) {
        if (ImGui::MenuItem("Create Empty")) Spawn("Empty");
        if (ImGui::MenuItem("Cube")) Spawn("Cube");
        if (ImGui::MenuItem("Sprite")) Spawn("Sprite");
        ImGui::EndPopup();
    }

    if (pendingDelete) {
        scene.Destroy(pendingDelete);
        pendingDelete = 0;
        if (!scene.Find(selected)) selected = 0;
        Commit();
    }
    ImGui::End();
}

// ====================================================================== inspector

void Editor::TextureField(const char* label, std::string& path) {
    char buf[260];
    std::snprintf(buf, sizeof buf, "%s", path.c_str());
    if (ImGui::InputText(label, buf, sizeof buf)) path = buf;
    if (ImGui::IsItemDeactivatedAfterEdit()) Commit();
    if (ImGui::BeginDragDropTarget()) {
        if (const ImGuiPayload* p = ImGui::AcceptDragDropPayload("ASSET_PATH")) {
            path = static_cast<const char*>(p->Data);
            Commit();
        }
        ImGui::EndDragDropTarget();
    }
    // اختيار صورة من قائمة الأصول (ضروري على الهاتف حيث لا يمكن السحب بين التبويبات)
    ImGui::SameLine();
    if (ImGui::Button("Pick")) {
        ScanAssets(assetFiles);
        lastAssetScan = Platform::Time();
        ImGui::OpenPopup("pick_tex");
    }
    if (ImGui::BeginPopup("pick_tex")) {
        if (ImGui::Selectable("(none)")) {
            path.clear();
            Commit();
        }
        for (const std::string& a : assetFiles) {
            if (!HasExt(a, {".png", ".jpg", ".jpeg", ".bmp", ".tga"})) continue;
            if (ImGui::Selectable(a.c_str())) {
                path = a;
                Commit();
            }
        }
        ImGui::EndPopup();
    }
}

void Editor::Inspector() {
    if (!Panel("Inspector", kTabInspector)) return;
    Entity* e = scene.Find(selected);
    if (!e) {
        ImGui::TextDisabled("No object selected.");
        ImGui::End();
        return;
    }
    auto edited = [&]() {
        if (ImGui::IsItemDeactivatedAfterEdit()) Commit();
    };

    ImGui::PushID(static_cast<int>(e->id));

    if (ImGui::Checkbox("##active", &e->active)) Commit();
    ImGui::SameLine();
    char nameBuf[128];
    std::snprintf(nameBuf, sizeof nameBuf, "%s", e->name.c_str());
    ImGui::SetNextItemWidth(-1);
    if (ImGui::InputText("##name", nameBuf, sizeof nameBuf)) e->name = nameBuf;
    edited();
    ImGui::Separator();

    // ---- Transform ----
    if (ImGui::CollapsingHeader("Transform", ImGuiTreeNodeFlags_DefaultOpen)) {
        Transform& t = e->transform;
        ImGui::DragFloat3("Position", t.position.data(), 0.05f);
        edited();
        ImGui::DragFloat3("Rotation", t.rotation.data(), 0.5f);
        edited();
        ImGui::DragFloat3("Scale", t.scale.data(), 0.02f);
        edited();
    }

    // ---- Mesh Renderer ----
    if (e->mesh) {
        ImGui::PushID("mesh");
        bool vis = true;
        if (ImGui::CollapsingHeader("Mesh Renderer", &vis, ImGuiTreeNodeFlags_DefaultOpen)) {
            MeshRenderer& m = *e->mesh;
            int type = static_cast<int>(m.mesh);
            if (ImGui::Combo("Mesh", &type, "Cube\0Sphere\0Plane\0Cylinder\0")) {
                m.mesh = static_cast<MeshType>(type);
                Commit();
            }
            ImGui::ColorEdit3("Color", m.color.data());
            edited();
            ImGui::DragFloat("Shininess", &m.shininess, 0.5f, 1.0f, 256.0f);
            edited();
            TextureField("Texture", m.texture);
        }
        ImGui::PopID();
        if (!vis) {
            e->mesh.reset();
            Commit();
        }
    }

    // ---- Sprite Renderer ----
    if (e->sprite) {
        ImGui::PushID("sprite");
        bool vis = true;
        if (ImGui::CollapsingHeader("Sprite Renderer (2D)", &vis, ImGuiTreeNodeFlags_DefaultOpen)) {
            SpriteRenderer& s = *e->sprite;
            ImGui::ColorEdit3("Color", s.color.data());
            edited();
            if (ImGui::Checkbox("Flip X", &s.flipX)) Commit();
            ImGui::DragInt("Sorting Order", &s.sortingOrder, 0.2f);
            edited();
            TextureField("Texture", s.texture);
        }
        ImGui::PopID();
        if (!vis) {
            e->sprite.reset();
            Commit();
        }
    }

    // ---- Light ----
    if (e->light) {
        ImGui::PushID("light");
        bool vis = true;
        if (ImGui::CollapsingHeader("Light", &vis, ImGuiTreeNodeFlags_DefaultOpen)) {
            Light& l = *e->light;
            int type = static_cast<int>(l.type);
            if (ImGui::Combo("Type", &type, "Directional\0Point\0")) {
                l.type = static_cast<LightType>(type);
                Commit();
            }
            ImGui::ColorEdit3("Color", l.color.data());
            edited();
            ImGui::DragFloat("Intensity", &l.intensity, 0.02f, 0.0f, 20.0f);
            edited();
            if (l.type == LightType::Point) {
                ImGui::DragFloat("Range", &l.range, 0.1f, 0.1f, 500.0f);
                edited();
            }
        }
        ImGui::PopID();
        if (!vis) {
            e->light.reset();
            Commit();
        }
    }

    // ---- Camera ----
    if (e->camera) {
        ImGui::PushID("camera");
        bool vis = true;
        if (ImGui::CollapsingHeader("Camera", &vis, ImGuiTreeNodeFlags_DefaultOpen)) {
            Camera& c = *e->camera;
            if (ImGui::Checkbox("Orthographic (2D)", &c.orthographic)) Commit();
            if (c.orthographic) {
                ImGui::DragFloat("Size", &c.orthoSize, 0.05f, 0.1f, 500.0f);
            } else {
                ImGui::DragFloat("Field of View", &c.fov, 0.2f, 10.0f, 150.0f);
            }
            edited();
            ImGui::DragFloat("Near", &c.nearPlane, 0.01f, 0.001f, 100.0f);
            edited();
            ImGui::DragFloat("Far", &c.farPlane, 1.0f, 1.0f, 10000.0f);
            edited();
            ImGui::ColorEdit3("Background", c.clearColor.data());
            edited();
        }
        ImGui::PopID();
        if (!vis) {
            e->camera.reset();
            Commit();
        }
    }

    // ---- RigidBody ----
    if (e->rigidbody) {
        ImGui::PushID("rb");
        bool vis = true;
        if (ImGui::CollapsingHeader("Rigid Body", &vis, ImGuiTreeNodeFlags_DefaultOpen)) {
            RigidBody& r = *e->rigidbody;
            ImGui::DragFloat("Mass", &r.mass, 0.05f, 0.01f, 1000.0f);
            edited();
            if (ImGui::Checkbox("Use Gravity", &r.useGravity)) Commit();
            if (ImGui::Checkbox("Is Kinematic", &r.isKinematic)) Commit();
            if (ImGui::Checkbox("Freeze Z (2D)", &r.freezeZ)) Commit();
            if (playing) {
                ImGui::Text("Velocity: %.2f, %.2f, %.2f", r.velocity.x, r.velocity.y, r.velocity.z);
                ImGui::Text("Grounded: %s", r.grounded ? "yes" : "no");
            }
        }
        ImGui::PopID();
        if (!vis) {
            e->rigidbody.reset();
            Commit();
        }
    }

    // ---- Box Collider ----
    if (e->collider) {
        ImGui::PushID("col");
        bool vis = true;
        if (ImGui::CollapsingHeader("Box Collider", &vis, ImGuiTreeNodeFlags_DefaultOpen)) {
            BoxCollider& c = *e->collider;
            ImGui::DragFloat3("Size", c.size.data(), 0.02f, 0.001f, 1000.0f);
            edited();
            ImGui::DragFloat3("Center", c.center.data(), 0.02f);
            edited();
        }
        ImGui::PopID();
        if (!vis) {
            e->collider.reset();
            Commit();
        }
    }

    // ---- Scripts ----
    for (size_t i = 0; i < e->scripts.size(); ++i) {
        Script& s = *e->scripts[i];
        ImGui::PushID(static_cast<int>(1000 + i));
        bool vis = true;
        bool open = ImGui::CollapsingHeader(s.TypeName(), &vis, ImGuiTreeNodeFlags_DefaultOpen);
        if (open) {
            for (auto& p : s.props) {
                ImGui::DragFloat(p.name.c_str(), p.value, 0.05f);
                edited();
            }
            if (s.props.empty()) ImGui::TextDisabled("(no exposed fields)");
        }
        ImGui::PopID();
        if (!vis) {
            e->RemoveScript(i);
            Commit();
            break;
        }
    }

    ImGui::Spacing();
    if (ImGui::Button("Add Component", ImVec2(-1, 0))) ImGui::OpenPopup("AddComponent");
    if (ImGui::BeginPopup("AddComponent")) {
        if (!e->mesh && ImGui::MenuItem("Mesh Renderer")) {
            e->mesh = MeshRenderer{};
            Commit();
        }
        if (!e->sprite && ImGui::MenuItem("Sprite Renderer (2D)")) {
            e->sprite = SpriteRenderer{};
            Commit();
        }
        if (!e->light && ImGui::MenuItem("Light")) {
            e->light = Light{};
            Commit();
        }
        if (!e->camera && ImGui::MenuItem("Camera")) {
            e->camera = Camera{};
            Commit();
        }
        if (!e->rigidbody && ImGui::MenuItem("Rigid Body")) {
            e->rigidbody = RigidBody{};
            Commit();
        }
        if (!e->collider && ImGui::MenuItem("Box Collider")) {
            e->collider = BoxCollider{};
            Commit();
        }
        ImGui::Separator();
        ImGui::TextDisabled("Scripts");
        for (const std::string& name : ScriptRegistry::Names()) {
            if (ImGui::MenuItem(name.c_str())) {
                e->AddScript(name);
                Commit();
            }
        }
        ImGui::EndPopup();
    }

    ImGui::PopID();
    ImGui::End();
}

// ====================================================================== scene view

Vec3 Editor::CameraForward() const {
    float y = Radians(yaw), p = Radians(pitch);
    return Vec3(-std::sin(y) * std::cos(p), std::sin(p), -std::cos(y) * std::cos(p));
}

void Editor::EditorCameraMatrices(float aspect, Mat4& view, Mat4& proj, Vec3& pos) const {
    if (view2D) {
        pos = Vec3(pan2DX, pan2DY, 50.0f);
        view = Mat4::LookAt(pos, Vec3(pan2DX, pan2DY, 0.0f), Vec3(0, 1, 0));
        float h = orthoSize, w = h * aspect;
        proj = Mat4::Ortho(-w, w, -h, h, 0.1f, 200.0f);
    } else {
        pos = camPos;
        view = Mat4::LookAt(camPos, camPos + CameraForward(), Vec3(0, 1, 0));
        proj = Mat4::Perspective(60.0f, aspect, 0.1f, 1000.0f);
    }
}

void Editor::FocusSelected() {
    Entity* e = scene.Find(selected);
    if (!e) return;
    Vec3 p = scene.WorldMatrix(*e).TransformPoint(Vec3(0, 0, 0));
    if (view2D) {
        pan2DX = p.x;
        pan2DY = p.y;
    } else {
        camPos = p - CameraForward() * 6.0f;
    }
}

EntityId Editor::Pick(const Vec3& o, const Vec3& d) const {
    EntityId best = 0;
    float bestT = 1e30f;
    for (auto& up : scene.Entities()) {
        const Entity& e = *up;
        if (!scene.IsActiveInHierarchy(e)) continue;
        Mat4 w;
        Vec3 half(0.5f, 0.5f, 0.5f);
        if (e.mesh) {
            w = scene.WorldMatrix(e);
        } else if (e.sprite) {
            w = scene.WorldMatrix(e);
            half = Vec3(0.5f, 0.5f, 0.05f);
        } else {  // نفس مكعب الأيقونة الذي يرسمه Renderer
            w = Mat4::Translate(scene.WorldMatrix(e).TransformPoint(Vec3(0, 0, 0))) * Mat4::Scale(Vec3(0.6f));
        }
        Mat4 inv = w.Inverse();
        Vec3 lo = inv.TransformPoint(o), ld = inv.TransformDir(d);
        float tmin = -1e30f, tmax = 1e30f;
        bool hit = true;
        for (int a = 0; a < 3 && hit; ++a) {
            if (std::fabs(ld[a]) < 1e-8f) {
                if (std::fabs(lo[a]) > half[a]) hit = false;
            } else {
                float t1 = (-half[a] - lo[a]) / ld[a], t2 = (half[a] - lo[a]) / ld[a];
                if (t1 > t2) std::swap(t1, t2);
                tmin = std::max(tmin, t1);
                tmax = std::min(tmax, t2);
                if (tmax < tmin) hit = false;
            }
        }
        if (!hit || tmax < 0.0f) continue;
        float t = std::max(tmin, 0.0f);
        if (t < bestT) {
            bestT = t;
            best = e.id;
        }
    }
    return best;
}

void Editor::SceneView() {
    if (!Panel("Scene", kTabScene)) return;
    ImGuiIO& io = ImGui::GetIO();

    // ---- شريط الأدوات (يلتف إلى سطر جديد إذا ضاق العرض) ----
    auto sameLine = [](const char* nextLabel) {
        float need = ImGui::GetFrameHeight() + ImGui::GetStyle().ItemInnerSpacing.x + ImGui::CalcTextSize(nextLabel).x;
        if (ImGui::GetContentRegionAvail().x > need + ImGui::GetStyle().ItemSpacing.x) ImGui::SameLine();
    };
    const char* lblMove = mobile ? "Move" : "Move (W)";
    const char* lblRot = mobile ? "Rotate" : "Rotate (E)";
    const char* lblScl = mobile ? "Scale" : "Scale (R)";
    if (ImGui::RadioButton(lblMove, gizmoOp == 0)) gizmoOp = 0;
    sameLine(lblRot);
    if (ImGui::RadioButton(lblRot, gizmoOp == 1)) gizmoOp = 1;
    sameLine(lblScl);
    if (ImGui::RadioButton(lblScl, gizmoOp == 2)) gizmoOp = 2;
    sameLine("2D");
    ImGui::Checkbox("2D", &view2D);
    sameLine("Grid");
    ImGui::Checkbox("Grid", &showGrid);
    sameLine("Local");
    ImGui::Checkbox("Local", &gizmoLocal);
    if (mobile) {
        sameLine("Look");
        ImGui::Checkbox("Look", &lookMode);
    }

    ImVec2 size = ImGui::GetContentRegionAvail();
    if (size.x < 8 || size.y < 8) {
        ImGui::End();
        return;
    }
    sceneFB.Resize(static_cast<int>(size.x), static_cast<int>(size.y));

    // ---- رسم المشهد ----
    float aspect = size.x / size.y;
    Mat4 view, proj;
    Vec3 eye;
    EditorCameraMatrices(aspect, view, proj, eye);

    Renderer::Options opt;
    opt.drawGrid = showGrid;
    opt.grid2D = view2D;
    opt.editorGizmos = true;
    opt.selected = selected;
    sceneFB.Bind();
    renderer.Render(scene, view, proj, eye, Vec3(0.17f, 0.18f, 0.21f), opt);
    sceneFB.Unbind();

    ImGui::Image(static_cast<ImTextureID>(static_cast<intptr_t>(sceneFB.ColorTexture())), size, ImVec2(0, 1),
                 ImVec2(1, 0));
    bool hovered = ImGui::IsItemHovered();
    ImVec2 rmin = ImGui::GetItemRectMin();

    // ---- Gizmo ----
    bool gizmoUsing = false, gizmoOver = false;
    Entity* sel = scene.Find(selected);
    if (sel && !playing) {
        ImGuizmo::SetOrthographic(view2D);
        ImGuizmo::SetGizmoSizeClipSpace(mobile ? 0.22f : 0.1f);  // أكبر على الهاتف ليسهل لمسه
        ImGuizmo::SetDrawlist();
        ImGuizmo::SetRect(rmin.x, rmin.y, size.x, size.y);
        Mat4 world = scene.WorldMatrix(*sel);
        ImGuizmo::OPERATION op = gizmoOp == 0 ? ImGuizmo::TRANSLATE : (gizmoOp == 1 ? ImGuizmo::ROTATE : ImGuizmo::SCALE);
        ImGuizmo::MODE mode = (gizmoLocal && gizmoOp != 2) ? ImGuizmo::LOCAL : ImGuizmo::WORLD;
        if (gizmoOp == 2) mode = ImGuizmo::LOCAL;
        if (ImGuizmo::Manipulate(view.m, proj.m, op, mode, world.m)) {
            Mat4 parentInv;
            if (sel->parent)
                if (Entity* p = scene.Find(sel->parent)) parentInv = scene.WorldMatrix(*p).Inverse();
            Mat4 local = parentInv * world;
            Vec3 pos, rot, scl;
            local.Decompose(pos, rot, scl);
            if (gizmoOp == 0) sel->transform.position = pos;
            else if (gizmoOp == 1) sel->transform.rotation = rot;
            else sel->transform.scale = scl;
        }
        gizmoUsing = ImGuizmo::IsUsing();
        gizmoOver = ImGuizmo::IsOver();
    }
    if (gizmoWasUsing && !gizmoUsing) Commit();
    gizmoWasUsing = gizmoUsing;

    // ---- التقاط الكائنات ----
    auto pickAt = [&](float px, float py) {
        float mx = (px - rmin.x) / size.x;
        float my = (py - rmin.y) / size.y;
        float nx = mx * 2.0f - 1.0f, ny = 1.0f - my * 2.0f;
        Mat4 invVP = (proj * view).Inverse();
        Vec3 nearP = invVP.TransformPointW(Vec3(nx, ny, -1.0f));
        Vec3 farP = invVP.TransformPointW(Vec3(nx, ny, 1.0f));
        selected = Pick(nearP, Normalize(farP - nearP));
    };
    const Touch& touch = Touch::State();
    if (!mobile) {
        if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left) && !gizmoOver && !gizmoUsing)
            pickAt(io.MousePos.x, io.MousePos.y);
    } else {
        // اللمس: نقرة قصيرة بإصبع واحد (لا سحب ولا إصبع ثانٍ ولا gizmo) ثم رفع الإصبع = تحديد
        float slop = ImGui::GetFontSize() * 0.8f;
        if (hovered && ImGui::IsMouseClicked(ImGuiMouseButton_Left)) {
            tapInRect = true;
            tapValid = !gizmoOver && !gizmoUsing;
            tapX = io.MousePos.x;
            tapY = io.MousePos.y;
        }
        if (tapInRect && ImGui::IsMouseDown(ImGuiMouseButton_Left)) {
            float dx = io.MousePos.x - tapX, dy = io.MousePos.y - tapY;
            if (dx * dx + dy * dy > slop * slop || touch.count >= 2 || gizmoUsing) tapValid = false;
        }
        if (ImGui::IsMouseReleased(ImGuiMouseButton_Left)) {
            if (tapInRect && tapValid && !lookMode) pickAt(tapX, tapY);
            tapInRect = false;
        }
    }

    // ---- التحكم بالكاميرا ----
    bool rmb = ImGui::IsMouseDown(ImGuiMouseButton_Right);
    bool mmb = ImGui::IsMouseDown(ImGuiMouseButton_Middle);
    if (hovered && (ImGui::IsMouseClicked(ImGuiMouseButton_Right) || ImGui::IsMouseClicked(ImGuiMouseButton_Middle)))
        sceneCamActive = true;
    if (!rmb && !mmb) sceneCamActive = false;

    if (sceneCamActive) {
        if (view2D) {
            float k = 2.0f * orthoSize / size.y;
            pan2DX -= io.MouseDelta.x * k;
            pan2DY += io.MouseDelta.y * k;
        } else if (rmb) {
            yaw -= io.MouseDelta.x * 0.2f;
            pitch = Clamp(pitch - io.MouseDelta.y * 0.2f, -89.0f, 89.0f);
            Vec3 f = CameraForward();
            Vec3 r = Normalize(Cross(f, Vec3(0, 1, 0)));
            float speed = 6.0f * (io.KeyShift ? 3.0f : 1.0f) * io.DeltaTime;
            if (ImGui::IsKeyDown(ImGuiKey_W)) camPos += f * speed;
            if (ImGui::IsKeyDown(ImGuiKey_S)) camPos -= f * speed;
            if (ImGui::IsKeyDown(ImGuiKey_D)) camPos += r * speed;
            if (ImGui::IsKeyDown(ImGuiKey_A)) camPos -= r * speed;
            if (ImGui::IsKeyDown(ImGuiKey_E)) camPos.y += speed;
            if (ImGui::IsKeyDown(ImGuiKey_Q)) camPos.y -= speed;
        }
    }
    if (mobile) {
        float u = 13.0f / ImGui::GetFontSize();  // يوحّد سرعة الإيماءات عبر كثافات الشاشات المختلفة
        bool twoFingers = touch.count >= 2;
        float midx = 0, midy = 0, dist = 0;
        if (twoFingers) {
            midx = (touch.x[0] + touch.x[1]) * 0.5f;
            midy = (touch.y[0] + touch.y[1]) * 0.5f;
            float dx = touch.x[0] - touch.x[1], dy = touch.y[0] - touch.y[1];
            dist = std::sqrt(dx * dx + dy * dy);
            twoFingers = midx >= rmin.x && midx <= rmin.x + size.x && midy >= rmin.y && midy <= rmin.y + size.y;
        }
        if (twoFingers) {
            if (pinchActive) {
                float dd = dist - prevPinchDist, mdx = midx - prevMidX, mdy = midy - prevMidY;
                if (view2D) {
                    if (dist > 1.0f && prevPinchDist > 1.0f)
                        orthoSize = Clamp(orthoSize * (prevPinchDist / dist), 0.5f, 300.0f);
                    float k = 2.0f * orthoSize / size.y;
                    pan2DX -= mdx * k;
                    pan2DY += mdy * k;
                } else {
                    Vec3 f = CameraForward();
                    Vec3 r = Normalize(Cross(f, Vec3(0, 1, 0)));
                    Vec3 up = Cross(r, f);
                    camPos += f * (dd * u * 0.05f);                  // تقريب/تبعيد الأصابع = حركة للأمام/الخلف
                    camPos -= r * (mdx * u * 0.03f);                 // سحب الإصبعين = إزاحة جانبية
                    camPos += up * (mdy * u * 0.03f);
                }
            }
            pinchActive = true;
            prevPinchDist = dist;
            prevMidX = midx;
            prevMidY = midy;
        } else {
            pinchActive = false;
        }
        // إصبع واحد في وضع Look: تدوير الكاميرا (أو إزاحة في 2D)
        if (lookMode && hovered && !pinchActive && touch.count < 2 && ImGui::IsMouseDown(ImGuiMouseButton_Left) &&
            !gizmoOver && !gizmoUsing) {
            if (view2D) {
                float k = 2.0f * orthoSize / size.y;
                pan2DX -= io.MouseDelta.x * k;
                pan2DY += io.MouseDelta.y * k;
            } else {
                yaw -= io.MouseDelta.x * u * 0.4f;
                pitch = Clamp(pitch - io.MouseDelta.y * u * 0.4f, -89.0f, 89.0f);
            }
        }
    }
    if (hovered && io.MouseWheel != 0.0f) {
        if (view2D) orthoSize = Clamp(orthoSize * (1.0f - io.MouseWheel * 0.1f), 0.5f, 300.0f);
        else camPos += CameraForward() * (io.MouseWheel * 1.5f);
    }

    // ---- اختصارات ----
    if (hovered && !sceneCamActive && !io.WantTextInput) {
        if (ImGui::IsKeyPressed(ImGuiKey_W, false)) gizmoOp = 0;
        if (ImGui::IsKeyPressed(ImGuiKey_E, false)) gizmoOp = 1;
        if (ImGui::IsKeyPressed(ImGuiKey_R, false)) gizmoOp = 2;
        if (ImGui::IsKeyPressed(ImGuiKey_F, false)) FocusSelected();
    }

    ImGui::SetCursorScreenPos(ImVec2(rmin.x + 8, rmin.y + 8));
    if (mobile)
        ImGui::TextDisabled(lookMode ? "Look: drag = rotate | 2 fingers: pinch = fly, drag = pan"
                                     : "Tap = select | drag gizmo = edit | 2 fingers: pinch = fly, drag = pan");
    else
        ImGui::TextDisabled(view2D ? "2D: right/middle drag = pan, wheel = zoom"
                                   : "3D: hold right mouse + WASD/QE = fly, wheel = zoom, F = focus");
    ImGui::End();
}

// ====================================================================== game view

void Editor::GameView() {
    gameFocused = false;
    if (!Panel("Game", kTabGame)) return;
    gameFocused = mobile ? true : ImGui::IsWindowFocused();

    Entity* camEntity = scene.MainCamera();
    if (!camEntity) {
        ImGui::TextDisabled("No active Camera in the scene. Add one from GameObject > Camera.");
        ImGui::End();
        return;
    }
    ImVec2 size = ImGui::GetContentRegionAvail();
    if (size.x < 8 || size.y < 8) {
        ImGui::End();
        return;
    }
    gameFB.Resize(static_cast<int>(size.x), static_cast<int>(size.y));

    const Camera& c = *camEntity->camera;
    Mat4 world = scene.WorldMatrix(*camEntity);
    Mat4 view = world.WithoutScale().Inverse();
    float aspect = size.x / size.y;
    Mat4 proj;
    if (c.orthographic) {
        float h = c.orthoSize, w = h * aspect;
        proj = Mat4::Ortho(-w, w, -h, h, c.nearPlane, c.farPlane);
    } else {
        proj = Mat4::Perspective(c.fov, aspect, c.nearPlane, c.farPlane);
    }
    Vec3 eye = world.TransformPoint(Vec3(0, 0, 0));

    gameFB.Bind();
    renderer.Render(scene, view, proj, eye, c.clearColor, Renderer::Options{});
    gameFB.Unbind();

    ImGui::Image(static_cast<ImTextureID>(static_cast<intptr_t>(gameFB.ColorTexture())), size, ImVec2(0, 1),
                 ImVec2(1, 0));
    ImVec2 gmin = ImGui::GetItemRectMin(), gmax = ImGui::GetItemRectMax();
    gameRect[0] = gmin.x;
    gameRect[1] = gmin.y;
    gameRect[2] = gmax.x;
    gameRect[3] = gmax.y;
    if (!playing) {
        ImGui::SetCursorScreenPos(ImVec2(gmin.x + 8, gmin.y + 8));
        ImGui::TextDisabled("Press Play to run the scene");
    } else if (mobile) {
        // عصا التحكم الافتراضية (يسار) وزر القفز (يمين)
        VirtualLayout l = MakeLayout(gameRect);
        ImDrawList* dl = ImGui::GetWindowDrawList();
        dl->AddCircleFilled(ImVec2(l.jx, l.jy), l.jr, IM_COL32(255, 255, 255, 40), 40);
        dl->AddCircle(ImVec2(l.jx, l.jy), l.jr, IM_COL32(255, 255, 255, 120), 40, 3.0f);
        dl->AddCircleFilled(ImVec2(l.jx + joyX * l.jr * 0.9f, l.jy - joyY * l.jr * 0.9f), l.jr * 0.38f,
                            IM_COL32(255, 255, 255, 150), 32);
        dl->AddCircleFilled(ImVec2(l.bx, l.by), l.br, jumpHeld ? IM_COL32(255, 160, 40, 190) : IM_COL32(255, 255, 255, 50), 32);
        dl->AddCircle(ImVec2(l.bx, l.by), l.br, IM_COL32(255, 255, 255, 140), 32, 3.0f);
        const char* jt = "Jump";
        ImVec2 ts = ImGui::CalcTextSize(jt);
        dl->AddText(ImVec2(l.bx - ts.x * 0.5f, l.by - ts.y * 0.5f), IM_COL32(255, 255, 255, 230), jt);
    }
    ImGui::End();
}

// ====================================================================== console / assets

void Editor::Console() {
    if (!Panel("Console", kTabConsole)) return;
    if (ImGui::Button("Clear")) Log::Clear();
    ImGui::SameLine();
    ImGui::Checkbox("Info", &showInfo);
    ImGui::SameLine();
    ImGui::Checkbox("Warnings", &showWarn);
    ImGui::SameLine();
    ImGui::Checkbox("Errors", &showError);
    ImGui::Separator();

    ImGui::BeginChild("##console_log", ImVec2(0, 0), false, ImGuiWindowFlags_HorizontalScrollbar);
    bool atBottom = ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 5.0f;
    for (const LogEntry& le : Log::Entries()) {
        if (le.level == LogLevel::Info && !showInfo) continue;
        if (le.level == LogLevel::Warning && !showWarn) continue;
        if (le.level == LogLevel::Error && !showError) continue;
        ImVec4 col = le.level == LogLevel::Error ? ImVec4(1.0f, 0.4f, 0.4f, 1.0f)
                     : le.level == LogLevel::Warning ? ImVec4(1.0f, 0.85f, 0.3f, 1.0f)
                                                     : ImVec4(0.85f, 0.85f, 0.85f, 1.0f);
        ImGui::PushStyleColor(ImGuiCol_Text, col);
        ImGui::TextUnformatted(le.text.c_str());
        ImGui::PopStyleColor();
    }
    if (atBottom) ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
    ImGui::End();
}

void Editor::Assets() {
    if (!Panel("Assets", kTabAssets)) return;
    double now = Platform::Time();
    if (now - lastAssetScan > 1.5) {
        ScanAssets(assetFiles);
        lastAssetScan = now;
    }
    if (mobile) {
        ImGui::TextWrapped("Tap a .nova scene to open it. Images are chosen from the Pick button of a Texture field.");
        ImGui::TextDisabled("Folder: %s/assets", Platform::DataDir());
    } else {
        ImGui::TextDisabled("Folder: assets/  |  Drag an image onto a Texture field  |  Double-click .nova to open");
    }
    ImGui::Separator();
    if (assetFiles.empty()) ImGui::TextDisabled("(empty) Put images and scenes in the assets folder.");

    for (const std::string& path : assetFiles) {
        bool isImage = HasExt(path, {".png", ".jpg", ".jpeg", ".bmp", ".tga"});
        bool isScene = HasExt(path, {".nova"});
        ImGui::Selectable(path.c_str(), false, ImGuiSelectableFlags_AllowDoubleClick);
        bool openIt = mobile ? ImGui::IsItemClicked(ImGuiMouseButton_Left)
                             : (ImGui::IsItemHovered() && ImGui::IsMouseDoubleClicked(ImGuiMouseButton_Left));
        if (isScene && openIt) {
            OpenScene(path);
            break;
        }
        if (isImage && ImGui::BeginDragDropSource()) {
            ImGui::SetDragDropPayload("ASSET_PATH", path.c_str(), path.size() + 1);
            ImGui::TextUnformatted(path.c_str());
            ImGui::EndDragDropSource();
        }
    }
    ImGui::End();
}

// ====================================================================== dialogs

void Editor::Dialogs() {
    if (openOpenDialog) {
        ImGui::OpenPopup("Open Scene");
        openOpenDialog = false;
    }
    if (openSaveDialog) {
        std::snprintf(pathBuf, sizeof pathBuf, "%s", currentPath.c_str());
        ImGui::OpenPopup("Save Scene As");
        openSaveDialog = false;
    }

    if (ImGui::BeginPopupModal("Open Scene", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ScanAssets(assetFiles);
        lastAssetScan = Platform::Time();
        bool any = false;
        for (const std::string& p : assetFiles) {
            if (!HasExt(p, {".nova"})) continue;
            any = true;
            if (ImGui::Selectable(p.c_str())) {
                OpenScene(p);
                ImGui::CloseCurrentPopup();
                break;
            }
        }
        if (!any) ImGui::TextDisabled("No .nova scenes in assets/ yet. Use File > Save As.");
        ImGui::Separator();
        if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }

    if (ImGui::BeginPopupModal("Save Scene As", nullptr, ImGuiWindowFlags_AlwaysAutoResize)) {
        ImGui::InputText("Path", pathBuf, sizeof pathBuf);
        if (ImGui::Button("Save")) {
            std::string p = pathBuf;
            if (!p.empty()) {
                if (!HasExt(p, {".nova"})) p += ".nova";
                SaveScene(p);
            }
            ImGui::CloseCurrentPopup();
        }
        ImGui::SameLine();
        if (ImGui::Button("Cancel")) ImGui::CloseCurrentPopup();
        ImGui::EndPopup();
    }
}

}  // namespace nova
