#pragma once
// واجهة المحرر: Hierarchy / Inspector / Scene / Game / Console / Assets
#include <string>
#include <vector>

#include "render/Framebuffer.h"
#include "render/Renderer.h"
#include "scene/Scene.h"

namespace nova {

class Editor {
public:
    Editor();
    ~Editor();  // يحذف خامات GL (يجب أن يُستدعى والسياق ما زال حيًا)

    // يُستدعى كل إطار بين ImGui::NewFrame و ImGui::Render
    void Frame(float dt);

    // حفظ/استعادة الجلسة تلقائيًا (أندرويد قد يدمّر السياق عند الخروج من التطبيق)
    void SaveSession();

private:
    // --- المشهد والملفات ---
    bool LoadSession();
    void BuildDemoScene();
    void NewScene();
    void OpenScene(const std::string& path);
    void SaveScene(const std::string& path);
    Entity* Spawn(const std::string& kind);
    void DeleteSelected();
    void DuplicateSelected();

    // --- التراجع والإعادة (لقطات نصية للمشهد) ---
    void Commit();  // يُستدعى بعد أي تعديل ليُسجَّل في سجل التراجع
    void Undo();
    void Redo();

    // --- وضع التشغيل ---
    void Play();
    void Stop();
    void FeedInput();

    // --- اللوحات ---
    enum Tab { kTabScene, kTabGame, kTabHierarchy, kTabInspector, kTabAssets, kTabConsole, kTabCount };
    bool Panel(const char* name, int tab, int extraFlags = 0);  // true = النافذة مفتوحة وعلى المستدعي استدعاء End()
    void MobileTabBar();
    void Shortcuts();
    void Dockspace();
    void MainMenu();
    void Hierarchy();
    void DrawHierarchyNode(Entity& e);
    void Inspector();
    void SceneView();
    void GameView();
    void Console();
    void Assets();
    void Dialogs();
    void TextureField(const char* label, std::string& path);

    // --- كاميرا المحرر ---
    Vec3 CameraForward() const;
    void EditorCameraMatrices(float aspect, Mat4& view, Mat4& proj, Vec3& pos) const;
    void FocusSelected();
    EntityId Pick(const Vec3& origin, const Vec3& dir) const;

    bool mobile = false;
    int activeTab = kTabScene;
    Scene scene;
    Renderer renderer;
    Framebuffer sceneFB, gameFB;

    EntityId selected = 0;
    EntityId pendingDelete = 0;

    bool playing = false, paused = false, gameFocused = false;
    std::string playSnapshot;

    std::string currentPath = "assets/untitled.nova";
    bool openOpenDialog = false, openSaveDialog = false;
    char pathBuf[260] = {};

    std::string lastSnapshot;
    std::vector<std::string> undoStack, redoStack;
    bool gizmoWasUsing = false;

    // كاميرا المشهد
    Vec3 camPos{0, 5, 12};
    float yaw = 0, pitch = -20;
    bool view2D = false, showGrid = true, gizmoLocal = false, sceneCamActive = false;
    float orthoSize = 6;
    float pan2DX = 0, pan2DY = 0;
    int gizmoOp = 0;  // 0 نقل، 1 تدوير، 2 تكبير

    // لوحة الأصول
    std::vector<std::string> assetFiles;
    double lastAssetScan = -100;

    // لوحة Console
    bool showInfo = true, showWarn = true, showError = true;

    bool layoutBuilt = false;

    // --- واجهة اللمس ---
    bool lookMode = false;                     // إصبع واحد يدير الكاميرا بدل التحديد
    bool tapInRect = false, tapValid = false;  // تتبّع النقرة الواحدة لتحديد الكائنات
    float tapX = 0, tapY = 0;
    bool pinchActive = false;
    float prevPinchDist = 0, prevMidX = 0, prevMidY = 0;
    float gameRect[4] = {0, 0, 0, 0};          // مستطيل نافذة Game بالبكسل (لعصا التحكم)
    float joyX = 0, joyY = 0;                  // وضع عصا التحكم للرسم
    bool jumpHeld = false;
};

}  // namespace nova
