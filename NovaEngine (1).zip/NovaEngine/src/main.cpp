// نقطة الدخول: ينشئ النافذة وسياق OpenGL و ImGui ثم يشغّل حلقة المحرر
#include <GL/glew.h>
// GLEW يجب أن يُضمَّن قبل GLFW
#include <GLFW/glfw3.h>
#include <imgui.h>
#include <imgui_impl_glfw.h>
#include <imgui_impl_opengl3.h>
#include <ImGuizmo.h>  // يجب أن يأتي بعد imgui.h

#include <cstdio>

#include "editor/Editor.h"
#include "platform/Platform.h"

// تنفيذ واجهة Platform لسطح المكتب
namespace nova {
namespace Platform {
static GLFWwindow* g_window = nullptr;
void RequestQuit() {
    if (g_window) glfwSetWindowShouldClose(g_window, GLFW_TRUE);
}
bool IsMobile() { return false; }
const char* DataDir() { return ""; }
}  // namespace Platform
}  // namespace nova

int main() {
    if (!glfwInit()) {
        std::fprintf(stderr, "Failed to initialize GLFW\n");
        return 1;
    }

    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE);
#ifdef __APPLE__
    glfwWindowHint(GLFW_OPENGL_FORWARD_COMPAT, GL_TRUE);
    const char* glslVersion = "#version 150";
#else
    const char* glslVersion = "#version 330";
#endif

    GLFWwindow* window = glfwCreateWindow(1600, 900, "Nova Engine", nullptr, nullptr);
    if (!window) {
        std::fprintf(stderr, "Failed to create window (OpenGL 3.3 required)\n");
        glfwTerminate();
        return 1;
    }
    nova::Platform::g_window = window;
    glfwMakeContextCurrent(window);
    glfwSwapInterval(1);

    glewExperimental = GL_TRUE;
    if (glewInit() != GLEW_OK) {
        std::fprintf(stderr, "Failed to initialize GLEW\n");
        return 1;
    }
    glGetError();  // يمسح خطأ GL_INVALID_ENUM المعروف بعد glewInit

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_DockingEnable;
    io.IniFilename = "nova_layout.ini";
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    style.WindowRounding = 3.0f;
    style.FrameRounding = 3.0f;
    style.TabRounding = 3.0f;

    ImGui_ImplGlfw_InitForOpenGL(window, true);
    ImGui_ImplOpenGL3_Init(glslVersion);

    {
        nova::Editor editor;  // يجب أن يُهدم قبل تدمير سياق OpenGL
        double last = glfwGetTime();
        while (!glfwWindowShouldClose(window)) {
            glfwPollEvents();

            ImGui_ImplOpenGL3_NewFrame();
            ImGui_ImplGlfw_NewFrame();
            ImGui::NewFrame();
            ImGuizmo::BeginFrame();

            double now = glfwGetTime();
            float dt = static_cast<float>(now - last);
            last = now;
            editor.Frame(dt);

            ImGui::Render();
            int fw = 0, fh = 0;
            glfwGetFramebufferSize(window, &fw, &fh);
            glViewport(0, 0, fw, fh);
            glClearColor(0.08f, 0.08f, 0.09f, 1.0f);
            glClear(GL_COLOR_BUFFER_BIT);
            ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
            glfwSwapBuffers(window);
        }
    }

    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplGlfw_Shutdown();
    ImGui::DestroyContext();
    glfwDestroyWindow(window);
    glfwTerminate();
    return 0;
}
