#pragma once
// حالة اللمس الخام (إحداثيات بالبكسل، حتى 5 أصابع). يغذّيها نظام أندرويد، ويبقى count = 0 على سطح المكتب.
namespace nova {

struct Touch {
    static constexpr int kMax = 5;
    int count = 0;
    float x[kMax] = {};
    float y[kMax] = {};

    static Touch& State() {
        static Touch t;
        return t;
    }
};

}  // namespace nova
