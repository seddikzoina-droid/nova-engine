#pragma once
// حالة الإدخال التي تقرأها السكربتات أثناء التشغيل (يغذّيها المحرر من نافذة Game)
#include <algorithm>

namespace nova {

enum class Key { W, A, S, D, Q, E, Space, Left, Right, Up, Down, Shift, Count };

class Input {
public:
    static bool& Down(Key k) {
        static bool keys[static_cast<int>(Key::Count)] = {};
        return keys[static_cast<int>(k)];
    }
    static bool GetKey(Key k) { return Down(k); }

    // محاور تناظرية (عصا التحكم الافتراضية على الهاتف): من -1 إلى 1
    static float& AnalogH() {
        static float v = 0.0f;
        return v;
    }
    static float& AnalogV() {
        static float v = 0.0f;
        return v;
    }
    static void ResetAll() {
        for (int k = 0; k < static_cast<int>(Key::Count); ++k) Down(static_cast<Key>(k)) = false;
        AnalogH() = 0.0f;
        AnalogV() = 0.0f;
    }

    static float Horizontal() {
        float h = ((GetKey(Key::D) || GetKey(Key::Right)) ? 1.0f : 0.0f) -
                  ((GetKey(Key::A) || GetKey(Key::Left)) ? 1.0f : 0.0f);
        return std::max(-1.0f, std::min(1.0f, h + AnalogH()));
    }
    static float Vertical() {
        float v = ((GetKey(Key::W) || GetKey(Key::Up)) ? 1.0f : 0.0f) -
                  ((GetKey(Key::S) || GetKey(Key::Down)) ? 1.0f : 0.0f);
        return std::max(-1.0f, std::min(1.0f, v + AnalogV()));
    }
};

}  // namespace nova
