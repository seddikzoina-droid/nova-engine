#pragma once
// سجل الرسائل: يظهر في لوحة Console داخل المحرر
#include <cstdio>
#include <string>
#include <vector>

#ifdef __ANDROID__
#include <android/log.h>
#endif

namespace nova {

enum class LogLevel { Info, Warning, Error };

struct LogEntry {
    LogLevel level;
    std::string text;
};

class Log {
public:
    static std::vector<LogEntry>& Entries() {
        static std::vector<LogEntry> entries;
        return entries;
    }
    static void Add(LogLevel level, const std::string& text) {
        auto& e = Entries();
        e.push_back({level, text});
        if (e.size() > 2000) e.erase(e.begin(), e.begin() + 500);
#ifdef __ANDROID__
        __android_log_print(level == LogLevel::Info ? ANDROID_LOG_INFO
                            : level == LogLevel::Warning ? ANDROID_LOG_WARN
                                                         : ANDROID_LOG_ERROR,
                            "NovaEngine", "%s", text.c_str());
#else
        std::fprintf(stdout, "[%s] %s\n",
                     level == LogLevel::Info ? "info" : (level == LogLevel::Warning ? "warn" : "error"),
                     text.c_str());
#endif
    }
    static void Info(const std::string& s) { Add(LogLevel::Info, s); }
    static void Warn(const std::string& s) { Add(LogLevel::Warning, s); }
    static void Error(const std::string& s) { Add(LogLevel::Error, s); }
    static void Clear() { Entries().clear(); }
};

}  // namespace nova
