// سكربتات جاهزة تأتي مع المحرر. استخدمها كقالب لكتابة سكربتاتك.
#include <cmath>

#include "core/Input.h"
#include "scene/Scene.h"

namespace nova {

// يدور الكائن حول محاوره (درجة/ثانية)
class Spinner : public Script {
public:
    float speedX = 0, speedY = 45, speedZ = 0;
    Spinner() {
        Expose("speedX", speedX);
        Expose("speedY", speedY);
        Expose("speedZ", speedZ);
    }
    const char* TypeName() const override { return "Spinner"; }
    void OnUpdate(float dt) override { entity->transform.rotation += Vec3(speedX, speedY, speedZ) * dt; }
};

// يتحرك الكائن جيئة وذهابًا
class Oscillator : public Script {
public:
    float amplitudeX = 0, amplitudeY = 1, amplitudeZ = 0, frequency = 0.5f;
    Oscillator() {
        Expose("amplitudeX", amplitudeX);
        Expose("amplitudeY", amplitudeY);
        Expose("amplitudeZ", amplitudeZ);
        Expose("frequency", frequency);
    }
    const char* TypeName() const override { return "Oscillator"; }
    void OnStart() override {
        base = entity->transform.position;
        time = 0;
    }
    void OnUpdate(float dt) override {
        time += dt;
        float s = std::sin(time * 2.0f * kPi * frequency);
        entity->transform.position = base + Vec3(amplitudeX * s, amplitudeY * s, amplitudeZ * s);
    }

private:
    Vec3 base;
    float time = 0;
};

// تحكم بلاعب: WASD أو الأسهم، ومسافة للقفز. mode2D=1 للألعاب الجانبية (X/Y)
class PlayerController : public Script {
public:
    float moveSpeed = 5, jumpSpeed = 7, mode2D = 0;
    PlayerController() {
        Expose("moveSpeed", moveSpeed);
        Expose("jumpSpeed", jumpSpeed);
        Expose("mode2D", mode2D);
    }
    const char* TypeName() const override { return "PlayerController"; }
    void OnUpdate(float dt) override {
        float h = Input::Horizontal();
        float v = Input::Vertical();
        bool is2D = mode2D > 0.5f;
        if (entity->rigidbody) {
            RigidBody& rb = *entity->rigidbody;
            rb.velocity.x = h * moveSpeed;
            if (!is2D) rb.velocity.z = -v * moveSpeed;
            if (Input::GetKey(Key::Space) && rb.grounded) rb.velocity.y = jumpSpeed;
        } else {
            Vec3& p = entity->transform.position;
            p.x += h * moveSpeed * dt;
            if (is2D) p.y += v * moveSpeed * dt;
            else p.z -= v * moveSpeed * dt;
        }
    }
};

// كاميرا تتبع كائنًا اسمه "Player" بسلاسة
class CameraFollow : public Script {
public:
    float offsetX = 0, offsetY = 6, offsetZ = 9, smooth = 5, lookAtTarget = 1;
    CameraFollow() {
        Expose("offsetX", offsetX);
        Expose("offsetY", offsetY);
        Expose("offsetZ", offsetZ);
        Expose("smooth", smooth);
        Expose("lookAtTarget", lookAtTarget);
    }
    const char* TypeName() const override { return "CameraFollow"; }
    void OnUpdate(float dt) override {
        Entity* target = scene->FindByName("Player");
        if (!target) return;
        Vec3 tp = scene->WorldMatrix(*target).TransformPoint(Vec3(0, 0, 0));
        Vec3 desired = tp + Vec3(offsetX, offsetY, offsetZ);
        float k = 1.0f - std::exp(-smooth * dt);
        Vec3& pos = entity->transform.position;
        pos = Lerp(pos, desired, k);
        if (lookAtTarget > 0.5f) {
            Vec3 d = Normalize(tp - pos);
            entity->transform.rotation = Vec3(Degrees(std::asin(Clamp(d.y, -1.0f, 1.0f))),
                                              Degrees(std::atan2(-d.x, -d.z)), 0.0f);
        }
    }
};

NOVA_REGISTER_SCRIPT(Spinner)
NOVA_REGISTER_SCRIPT(Oscillator)
NOVA_REGISTER_SCRIPT(PlayerController)
NOVA_REGISTER_SCRIPT(CameraFollow)

}  // namespace nova
