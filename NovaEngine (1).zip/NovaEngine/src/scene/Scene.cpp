#include "scene/Scene.h"

#include <algorithm>
#include <cmath>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <locale>
#include <sstream>

#include "core/Log.h"

namespace nova {

namespace {
std::string Trim(const std::string& s) {
    size_t a = s.find_first_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    size_t b = s.find_last_not_of(" \t\r\n");
    return s.substr(a, b - a + 1);
}
std::string OneLine(std::string s) {
    for (char& c : s)
        if (c == '\n' || c == '\r') c = ' ';
    return s;
}
}  // namespace

// ---------------------------------------------------------------- Entity

Script* Entity::AddScript(const std::string& typeName) {
    auto s = ScriptRegistry::Create(typeName);
    if (!s) {
        Log::Warn("Unknown script: " + typeName);
        return nullptr;
    }
    s->entity = this;
    s->scene = scene;
    scripts.push_back(std::move(s));
    return scripts.back().get();
}

void Entity::RemoveScript(size_t index) {
    if (index < scripts.size()) scripts.erase(scripts.begin() + static_cast<long>(index));
}

// ---------------------------------------------------------------- Scene: objects

Entity* Scene::Create(const std::string& name, EntityId parent) {
    auto up = std::make_unique<Entity>();
    up->id = nextId++;
    up->name = name;
    up->scene = this;
    Entity* e = up.get();
    index[e->id] = e;
    entities.push_back(std::move(up));
    if (parent) {
        if (Entity* p = Find(parent)) {
            e->parent = parent;
            p->children.push_back(e->id);
        }
    }
    return e;
}

Entity* Scene::Find(EntityId id) const {
    auto it = index.find(id);
    return it == index.end() ? nullptr : it->second;
}

Entity* Scene::FindByName(const std::string& name) const {
    for (auto& e : entities)
        if (e->name == name) return e.get();
    return nullptr;
}

void Scene::Destroy(EntityId id) {
    Entity* e = Find(id);
    if (!e) return;
    std::vector<EntityId> kids = e->children;
    for (EntityId k : kids) Destroy(k);
    if (e->parent) {
        if (Entity* p = Find(e->parent)) {
            auto& c = p->children;
            c.erase(std::remove(c.begin(), c.end(), id), c.end());
        }
    }
    index.erase(id);
    entities.erase(std::remove_if(entities.begin(), entities.end(),
                                  [id](const std::unique_ptr<Entity>& u) { return u->id == id; }),
                   entities.end());
}

bool Scene::IsDescendant(EntityId node, EntityId ancestor) const {
    EntityId cur = node;
    for (int guard = 0; cur && guard < 256; ++guard) {
        if (cur == ancestor) return true;
        Entity* e = Find(cur);
        if (!e) return false;
        cur = e->parent;
    }
    return false;
}

bool Scene::SetParent(EntityId childId, EntityId parentId) {
    Entity* child = Find(childId);
    if (!child) return false;
    if (parentId && !Find(parentId)) return false;
    if (parentId && IsDescendant(parentId, childId)) return false;  // يمنع الحلقات
    if (child->parent == parentId) return false;

    Vec3 worldPos = WorldMatrix(*child).TransformPoint(Vec3(0, 0, 0));

    if (child->parent) {
        if (Entity* old = Find(child->parent)) {
            auto& c = old->children;
            c.erase(std::remove(c.begin(), c.end(), childId), c.end());
        }
    }
    child->parent = parentId;
    if (parentId) {
        Entity* p = Find(parentId);
        p->children.push_back(childId);
        child->transform.position = WorldMatrix(*p).Inverse().TransformPoint(worldPos);
    } else {
        child->transform.position = worldPos;
    }
    return true;
}

EntityId Scene::CloneRecursive(const Entity& src, EntityId parent) {
    Entity* c = Create(src.name, parent);
    c->active = src.active;
    c->transform = src.transform;
    c->mesh = src.mesh;
    c->sprite = src.sprite;
    c->light = src.light;
    c->camera = src.camera;
    c->rigidbody = src.rigidbody;
    c->collider = src.collider;
    for (auto& s : src.scripts) {
        if (Script* ns = c->AddScript(s->TypeName())) {
            for (auto& p : s->props)
                for (auto& q : ns->props)
                    if (q.name == p.name) *q.value = *p.value;
        }
    }
    std::vector<EntityId> kids = src.children;
    for (EntityId k : kids)
        if (Entity* ke = Find(k)) CloneRecursive(*ke, c->id);
    return c->id;
}

EntityId Scene::Duplicate(EntityId id) {
    Entity* src = Find(id);
    if (!src) return 0;
    EntityId nid = CloneRecursive(*src, src->parent);
    if (Entity* n = Find(nid)) n->name += " (Copy)";
    return nid;
}

void Scene::Clear() {
    entities.clear();
    index.clear();
    nextId = 1;
}

Mat4 Scene::WorldMatrix(const Entity& e) const {
    Mat4 m = Mat4::TRS(e.transform.position, e.transform.rotation, e.transform.scale);
    const Entity* cur = &e;
    for (int guard = 0; cur->parent && guard < 64; ++guard) {
        const Entity* p = Find(cur->parent);
        if (!p) break;
        m = Mat4::TRS(p->transform.position, p->transform.rotation, p->transform.scale) * m;
        cur = p;
    }
    return m;
}

bool Scene::IsActiveInHierarchy(const Entity& e) const {
    const Entity* cur = &e;
    for (int guard = 0; cur && guard < 64; ++guard) {
        if (!cur->active) return false;
        cur = cur->parent ? Find(cur->parent) : nullptr;
    }
    return true;
}

Entity* Scene::MainCamera() const {
    for (auto& e : entities)
        if (e->camera && IsActiveInHierarchy(*e)) return e.get();
    return nullptr;
}

// ---------------------------------------------------------------- Scene: runtime

void Scene::Start() {
    for (auto& e : entities) {
        if (e->rigidbody) {
            e->rigidbody->velocity = Vec3(0, 0, 0);
            e->rigidbody->grounded = false;
        }
    }
    for (size_t i = 0; i < entities.size(); ++i) {
        Entity& e = *entities[i];
        for (size_t k = 0; k < e.scripts.size(); ++k) {
            e.scripts[k]->entity = &e;
            e.scripts[k]->scene = this;
            e.scripts[k]->OnStart();
        }
    }
}

void Scene::Update(float dt) {
    for (size_t i = 0; i < entities.size(); ++i) {
        Entity& e = *entities[i];
        if (!IsActiveInHierarchy(e)) continue;
        for (size_t k = 0; k < e.scripts.size(); ++k) e.scripts[k]->OnUpdate(dt);
    }
    int steps = std::max(1, static_cast<int>(std::ceil(dt / (1.0f / 120.0f))));
    steps = std::min(steps, 16);
    for (int s = 0; s < steps; ++s) StepPhysics(dt / static_cast<float>(steps));
}

// فيزياء مبسطة: جاذبية + تصادم AABB (الصناديق لا تدور). تعمل على الكائنات غير المرتبطة بأب.
void Scene::StepPhysics(float dt) {
    struct Box {
        const Entity* e;
        Vec3 c, h;
    };
    auto boxOf = [this](const Entity& e, Vec3& c, Vec3& h) {
        Mat4 w = WorldMatrix(e);
        Vec3 p, r, s;
        w.Decompose(p, r, s);
        c = w.TransformPoint(e.collider->center);
        h = Vec3(0.5f * e.collider->size.x * std::fabs(s.x), 0.5f * e.collider->size.y * std::fabs(s.y),
                 0.5f * e.collider->size.z * std::fabs(s.z));
    };

    std::vector<Box> boxes;
    for (auto& up : entities) {
        const Entity& e = *up;
        if (!e.collider || !IsActiveInHierarchy(e)) continue;
        Box b;
        b.e = &e;
        boxOf(e, b.c, b.h);
        boxes.push_back(b);
    }

    for (auto& up : entities) {
        Entity& e = *up;
        if (!e.rigidbody || !IsActiveInHierarchy(e)) continue;
        RigidBody& rb = *e.rigidbody;
        if (rb.isKinematic) continue;

        if (rb.useGravity) rb.velocity.y -= 9.81f * dt;
        if (rb.freezeZ) rb.velocity.z = 0.0f;
        e.transform.position += rb.velocity * dt;
        rb.grounded = false;
        if (!e.collider) continue;

        Vec3 c, h;
        boxOf(e, c, h);
        for (int iter = 0; iter < 3; ++iter) {
            for (const Box& o : boxes) {
                if (o.e == &e) continue;
                Vec3 d = c - o.c;
                float ox = h.x + o.h.x - std::fabs(d.x);
                float oy = h.y + o.h.y - std::fabs(d.y);
                float oz = h.z + o.h.z - std::fabs(d.z);
                if (ox <= 0 || oy <= 0 || oz <= 0) continue;
                if (rb.freezeZ) oz = 1e9f;
                int axis = 0;
                float best = ox;
                if (oy < best) { best = oy; axis = 1; }
                if (oz < best) { best = oz; axis = 2; }
                float sign = d[axis] >= 0.0f ? 1.0f : -1.0f;
                Vec3 push(0, 0, 0);
                push[axis] = sign * best;
                c += push;
                e.transform.position += push;
                if (sign * rb.velocity[axis] < 0.0f) rb.velocity[axis] = 0.0f;
                if (axis == 1 && sign > 0.0f) rb.grounded = true;
            }
        }
    }
}

// ---------------------------------------------------------------- Scene: save / load

std::string Scene::Serialize() const {
    std::ostringstream o;
    o.imbue(std::locale::classic());
    o << std::setprecision(9);
    o << "NOVA_SCENE 1\n";
    for (auto& up : entities) {
        const Entity& e = *up;
        o << "entity " << e.id << ' ' << e.parent << ' ' << (e.active ? 1 : 0) << ' ' << OneLine(e.name) << '\n';
        const Transform& t = e.transform;
        o << "transform " << t.position.x << ' ' << t.position.y << ' ' << t.position.z << ' ' << t.rotation.x
          << ' ' << t.rotation.y << ' ' << t.rotation.z << ' ' << t.scale.x << ' ' << t.scale.y << ' '
          << t.scale.z << '\n';
        if (e.mesh) {
            const auto& m = *e.mesh;
            o << "mesh " << static_cast<int>(m.mesh) << ' ' << m.color.x << ' ' << m.color.y << ' ' << m.color.z
              << ' ' << m.shininess << ' ' << OneLine(m.texture) << '\n';
        }
        if (e.sprite) {
            const auto& s = *e.sprite;
            o << "sprite " << s.color.x << ' ' << s.color.y << ' ' << s.color.z << ' ' << (s.flipX ? 1 : 0) << ' '
              << s.sortingOrder << ' ' << OneLine(s.texture) << '\n';
        }
        if (e.light) {
            const auto& l = *e.light;
            o << "light " << static_cast<int>(l.type) << ' ' << l.color.x << ' ' << l.color.y << ' ' << l.color.z
              << ' ' << l.intensity << ' ' << l.range << '\n';
        }
        if (e.camera) {
            const auto& c = *e.camera;
            o << "camera " << (c.orthographic ? 1 : 0) << ' ' << c.fov << ' ' << c.orthoSize << ' ' << c.nearPlane
              << ' ' << c.farPlane << ' ' << c.clearColor.x << ' ' << c.clearColor.y << ' ' << c.clearColor.z
              << '\n';
        }
        if (e.rigidbody) {
            const auto& r = *e.rigidbody;
            o << "rigidbody " << r.mass << ' ' << (r.useGravity ? 1 : 0) << ' ' << (r.isKinematic ? 1 : 0) << ' '
              << (r.freezeZ ? 1 : 0) << '\n';
        }
        if (e.collider) {
            const auto& c = *e.collider;
            o << "collider " << c.size.x << ' ' << c.size.y << ' ' << c.size.z << ' ' << c.center.x << ' '
              << c.center.y << ' ' << c.center.z << '\n';
        }
        for (auto& s : e.scripts) {
            o << "script " << s->TypeName();
            for (auto& p : s->props) o << ' ' << p.name << '=' << *p.value;
            o << '\n';
        }
        o << "end\n";
    }
    return o.str();
}

bool Scene::Deserialize(const std::string& text) {
    std::istringstream in(text);
    in.imbue(std::locale::classic());
    std::string line;
    if (!std::getline(in, line) || line.rfind("NOVA_SCENE", 0) != 0) {
        Log::Error("Not a valid Nova scene file");
        return false;
    }

    std::vector<std::unique_ptr<Entity>> newEntities;
    std::unordered_map<EntityId, Entity*> newIndex;
    std::vector<std::pair<EntityId, EntityId>> parentLinks;
    Entity* cur = nullptr;
    EntityId maxId = 0;

    while (std::getline(in, line)) {
        line = Trim(line);
        if (line.empty()) continue;
        std::istringstream ls(line);
        ls.imbue(std::locale::classic());
        std::string tag;
        ls >> tag;

        if (tag == "entity") {
            auto e = std::make_unique<Entity>();
            EntityId parentId = 0;
            int act = 1;
            ls >> e->id >> parentId >> act;
            std::string rest;
            std::getline(ls, rest);
            e->name = Trim(rest);
            e->active = act != 0;
            e->scene = this;
            maxId = std::max(maxId, e->id);
            cur = e.get();
            newIndex[e->id] = cur;
            parentLinks.emplace_back(e->id, parentId);
            newEntities.push_back(std::move(e));
        } else if (!cur) {
            continue;
        } else if (tag == "transform") {
            Transform& t = cur->transform;
            ls >> t.position.x >> t.position.y >> t.position.z >> t.rotation.x >> t.rotation.y >> t.rotation.z >>
                t.scale.x >> t.scale.y >> t.scale.z;
        } else if (tag == "mesh") {
            MeshRenderer m;
            int type = 0;
            ls >> type >> m.color.x >> m.color.y >> m.color.z >> m.shininess;
            m.mesh = static_cast<MeshType>(std::clamp(type, 0, 3));
            std::string rest;
            std::getline(ls, rest);
            m.texture = Trim(rest);
            cur->mesh = m;
        } else if (tag == "sprite") {
            SpriteRenderer s;
            int flip = 0;
            ls >> s.color.x >> s.color.y >> s.color.z >> flip >> s.sortingOrder;
            s.flipX = flip != 0;
            std::string rest;
            std::getline(ls, rest);
            s.texture = Trim(rest);
            cur->sprite = s;
        } else if (tag == "light") {
            Light l;
            int type = 0;
            ls >> type >> l.color.x >> l.color.y >> l.color.z >> l.intensity >> l.range;
            l.type = type == 1 ? LightType::Point : LightType::Directional;
            cur->light = l;
        } else if (tag == "camera") {
            Camera c;
            int ortho = 0;
            ls >> ortho >> c.fov >> c.orthoSize >> c.nearPlane >> c.farPlane >> c.clearColor.x >> c.clearColor.y >>
                c.clearColor.z;
            c.orthographic = ortho != 0;
            cur->camera = c;
        } else if (tag == "rigidbody") {
            RigidBody r;
            int g = 1, k = 0, fz = 0;
            ls >> r.mass >> g >> k >> fz;
            r.useGravity = g != 0;
            r.isKinematic = k != 0;
            r.freezeZ = fz != 0;
            cur->rigidbody = r;
        } else if (tag == "collider") {
            BoxCollider c;
            ls >> c.size.x >> c.size.y >> c.size.z >> c.center.x >> c.center.y >> c.center.z;
            cur->collider = c;
        } else if (tag == "script") {
            std::string name;
            ls >> name;
            if (Script* s = cur->AddScript(name)) {
                std::string kv;
                while (ls >> kv) {
                    size_t eq = kv.find('=');
                    if (eq == std::string::npos) continue;
                    std::string key = kv.substr(0, eq);
                    float val = 0;
                    try {
                        val = std::stof(kv.substr(eq + 1));
                    } catch (...) {
                        continue;
                    }
                    for (auto& p : s->props)
                        if (p.name == key) *p.value = val;
                }
            }
        } else if (tag == "end") {
            cur = nullptr;
        }
    }

    // نجاح التحليل: استبدل المشهد الحالي
    entities = std::move(newEntities);
    index = std::move(newIndex);
    for (auto& up : entities) up->scene = this;
    for (auto& link : parentLinks) {
        Entity* child = index[link.first];
        auto pit = index.find(link.second);
        if (link.second != 0 && pit != index.end() && link.second != link.first) {
            child->parent = link.second;
            pit->second->children.push_back(link.first);
        } else {
            child->parent = 0;
        }
    }
    nextId = maxId + 1;
    return true;
}

bool Scene::SaveToFile(const std::string& path) const {
    std::error_code ec;
    std::filesystem::path p(path);
    if (p.has_parent_path()) std::filesystem::create_directories(p.parent_path(), ec);
    std::ofstream f(path, std::ios::binary);
    if (!f) {
        Log::Error("Cannot write file: " + path);
        return false;
    }
    f << Serialize();
    return static_cast<bool>(f);
}

bool Scene::LoadFromFile(const std::string& path) {
    std::ifstream f(path, std::ios::binary);
    if (!f) {
        Log::Error("Cannot open file: " + path);
        return false;
    }
    std::stringstream ss;
    ss << f.rdbuf();
    return Deserialize(ss.str());
}

}  // namespace nova
