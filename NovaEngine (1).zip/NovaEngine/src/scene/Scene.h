#pragma once
// المشهد: يحتفظ بالكائنات والتسلسل الهرمي، ويشغّل السكربتات والفيزياء، ويحفظ ويحمّل الملفات
#include <string>
#include <unordered_map>
#include <vector>

#include "scene/Components.h"

namespace nova {

class Scene {
public:
    Scene() = default;
    Scene(const Scene&) = delete;
    Scene& operator=(const Scene&) = delete;

    // --- الكائنات ---
    Entity* Create(const std::string& name, EntityId parent = 0);
    Entity* Find(EntityId id) const;
    Entity* FindByName(const std::string& name) const;
    void Destroy(EntityId id);                       // يحذف الكائن وأبناءه
    bool SetParent(EntityId child, EntityId parent); // 0 = بدون أب. يحافظ على موضع العالم
    EntityId Duplicate(EntityId id);                 // نسخ مع الأبناء والسكربتات
    void Clear();
    const std::vector<std::unique_ptr<Entity>>& Entities() const { return entities; }

    // --- التحويلات ---
    Mat4 WorldMatrix(const Entity& e) const;
    bool IsActiveInHierarchy(const Entity& e) const;
    bool IsDescendant(EntityId node, EntityId ancestor) const;  // يعيد true إذا node == ancestor أيضًا
    Entity* MainCamera() const;

    // --- وقت التشغيل ---
    void Start();
    void Update(float dt);

    // --- الحفظ والتحميل (نص عادي قابل للقراءة) ---
    std::string Serialize() const;
    bool Deserialize(const std::string& text);
    bool SaveToFile(const std::string& path) const;
    bool LoadFromFile(const std::string& path);

private:
    EntityId CloneRecursive(const Entity& src, EntityId parent);
    void StepPhysics(float dt);

    std::vector<std::unique_ptr<Entity>> entities;
    std::unordered_map<EntityId, Entity*> index;
    EntityId nextId = 1;
};

}  // namespace nova
