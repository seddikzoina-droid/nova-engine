#pragma once
// نظام السكربتات: اكتب صنفًا يرث من Script وسجّله بـ NOVA_REGISTER_SCRIPT
// وسيظهر تلقائيًا في Add Component، وحقوله المكشوفة بـ Expose تظهر في Inspector وتُحفظ مع المشهد.
#include <functional>
#include <map>
#include <memory>
#include <string>
#include <vector>

namespace nova {

struct Entity;
class Scene;

class Script {
public:
    struct Prop {
        std::string name;
        float* value;
    };

    virtual ~Script() = default;
    virtual const char* TypeName() const = 0;
    virtual void OnStart() {}
    virtual void OnUpdate(float dt) {}

    Entity* entity = nullptr;
    Scene* scene = nullptr;
    std::vector<Prop> props;

protected:
    void Expose(const char* name, float& value) { props.push_back({name, &value}); }
};

class ScriptRegistry {
public:
    using Factory = std::function<std::unique_ptr<Script>()>;

    static std::map<std::string, Factory>& Factories() {
        static std::map<std::string, Factory> f;
        return f;
    }
    static void Register(const std::string& name, Factory f) { Factories()[name] = std::move(f); }
    static std::unique_ptr<Script> Create(const std::string& name) {
        auto it = Factories().find(name);
        return it == Factories().end() ? nullptr : it->second();
    }
    static std::vector<std::string> Names() {
        std::vector<std::string> out;
        for (auto& kv : Factories()) out.push_back(kv.first);
        return out;
    }
};

}  // namespace nova

#define NOVA_REGISTER_SCRIPT(Type)                                                          \
    namespace {                                                                             \
    const bool kRegistered_##Type = (::nova::ScriptRegistry::Register(                      \
                                         #Type,                                             \
                                         []() -> std::unique_ptr<::nova::Script> {          \
                                             return std::make_unique<Type>();               \
                                         }),                                                \
                                     true);                                                 \
    }
