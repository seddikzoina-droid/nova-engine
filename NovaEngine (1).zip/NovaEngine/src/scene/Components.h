#pragma once
// المكونات والكائنات (Entity) — بنية مشابهة لـ GameObject في Unity
#include <cstdint>
#include <memory>
#include <optional>
#include <string>
#include <vector>

#include "core/Math.h"
#include "scene/Script.h"

namespace nova {

class Scene;
using EntityId = uint32_t;

enum class MeshType : int { Cube = 0, Sphere, Plane, Cylinder };
enum class LightType : int { Directional = 0, Point };

struct Transform {
    Vec3 position{0, 0, 0};
    Vec3 rotation{0, 0, 0};  // درجات
    Vec3 scale{1, 1, 1};
};

struct MeshRenderer {
    MeshType mesh = MeshType::Cube;
    Vec3 color{0.8f, 0.8f, 0.8f};
    float shininess = 32.0f;
    std::string texture;  // مسار نسبي مثل assets/brick.png
};

// للألعاب ثنائية الأبعاد (2D)
struct SpriteRenderer {
    Vec3 color{1, 1, 1};
    std::string texture;
    bool flipX = false;
    int sortingOrder = 0;
};

struct Light {
    LightType type = LightType::Directional;
    Vec3 color{1, 1, 1};
    float intensity = 1.0f;
    float range = 10.0f;
};

struct Camera {
    bool orthographic = false;  // true للألعاب 2D
    float fov = 60.0f;
    float orthoSize = 5.0f;
    float nearPlane = 0.1f;
    float farPlane = 500.0f;
    Vec3 clearColor{0.12f, 0.14f, 0.18f};
};

struct RigidBody {
    float mass = 1.0f;
    bool useGravity = true;
    bool isKinematic = false;
    bool freezeZ = false;  // فعّلها في ألعاب 2D
    Vec3 velocity{0, 0, 0};
    bool grounded = false;  // للقراءة فقط (وقت التشغيل)
};

struct BoxCollider {
    Vec3 size{1, 1, 1};
    Vec3 center{0, 0, 0};
};

struct Entity {
    EntityId id = 0;
    std::string name;
    bool active = true;
    EntityId parent = 0;
    std::vector<EntityId> children;
    Scene* scene = nullptr;

    Transform transform;
    std::optional<MeshRenderer> mesh;
    std::optional<SpriteRenderer> sprite;
    std::optional<Light> light;
    std::optional<Camera> camera;
    std::optional<RigidBody> rigidbody;
    std::optional<BoxCollider> collider;
    std::vector<std::unique_ptr<Script>> scripts;

    Script* AddScript(const std::string& typeName);
    void RemoveScript(size_t index);
};

}  // namespace nova
