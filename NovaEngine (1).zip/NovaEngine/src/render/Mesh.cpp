#include "render/Mesh.h"

#include <cmath>

#include "core/Math.h"

namespace nova {

Mesh::Mesh(const std::vector<Vertex>& vertices, const std::vector<unsigned>& indices) {
    count = static_cast<GLsizei>(indices.size());
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glGenBuffers(1, &ebo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(vertices.size() * sizeof(Vertex)), vertices.data(),
                 GL_STATIC_DRAW);
    glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    glBufferData(GL_ELEMENT_ARRAY_BUFFER, static_cast<GLsizeiptr>(indices.size() * sizeof(unsigned)), indices.data(),
                 GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(0));
    glEnableVertexAttribArray(1);
    glVertexAttribPointer(1, 3, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(3 * sizeof(float)));
    glEnableVertexAttribArray(2);
    glVertexAttribPointer(2, 2, GL_FLOAT, GL_FALSE, sizeof(Vertex), reinterpret_cast<void*>(6 * sizeof(float)));
    glBindVertexArray(0);
}

Mesh::~Mesh() {
    glDeleteBuffers(1, &vbo);
    glDeleteBuffers(1, &ebo);
    glDeleteVertexArrays(1, &vao);
}

void Mesh::Draw() const {
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, count, GL_UNSIGNED_INT, nullptr);
    glBindVertexArray(0);
}

LineMesh::LineMesh(const std::vector<float>& xyz) {
    count = static_cast<GLsizei>(xyz.size() / 3);
    glGenVertexArrays(1, &vao);
    glGenBuffers(1, &vbo);
    glBindVertexArray(vao);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glBufferData(GL_ARRAY_BUFFER, static_cast<GLsizeiptr>(xyz.size() * sizeof(float)), xyz.data(), GL_STATIC_DRAW);
    glEnableVertexAttribArray(0);
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3 * sizeof(float), reinterpret_cast<void*>(0));
    glBindVertexArray(0);
}

LineMesh::~LineMesh() {
    glDeleteBuffers(1, &vbo);
    glDeleteVertexArrays(1, &vao);
}

void LineMesh::Draw() const {
    glBindVertexArray(vao);
    glDrawArrays(GL_LINES, 0, count);
    glBindVertexArray(0);
}

namespace MeshFactory {

// وجه مربع: المركز n*0.5 والمحوران u,w بحيث cross(u,w) = n (ترتيب عكس عقارب الساعة من الخارج)
static void Face(std::vector<Vertex>& v, std::vector<unsigned>& idx, Vec3 n, Vec3 u, Vec3 w) {
    unsigned base = static_cast<unsigned>(v.size());
    const float sa[4] = {-1, 1, 1, -1};
    const float sb[4] = {-1, -1, 1, 1};
    for (int i = 0; i < 4; ++i) {
        Vec3 p = n * 0.5f + u * (sa[i] * 0.5f) + w * (sb[i] * 0.5f);
        v.push_back({p.x, p.y, p.z, n.x, n.y, n.z, sa[i] * 0.5f + 0.5f, sb[i] * 0.5f + 0.5f});
    }
    idx.insert(idx.end(), {base, base + 1, base + 2, base, base + 2, base + 3});
}

std::unique_ptr<Mesh> Cube() {
    std::vector<Vertex> v;
    std::vector<unsigned> i;
    Face(v, i, Vec3(0, 0, 1), Vec3(1, 0, 0), Vec3(0, 1, 0));
    Face(v, i, Vec3(0, 0, -1), Vec3(-1, 0, 0), Vec3(0, 1, 0));
    Face(v, i, Vec3(1, 0, 0), Vec3(0, 0, -1), Vec3(0, 1, 0));
    Face(v, i, Vec3(-1, 0, 0), Vec3(0, 0, 1), Vec3(0, 1, 0));
    Face(v, i, Vec3(0, 1, 0), Vec3(1, 0, 0), Vec3(0, 0, -1));
    Face(v, i, Vec3(0, -1, 0), Vec3(1, 0, 0), Vec3(0, 0, 1));
    return std::make_unique<Mesh>(v, i);
}

std::unique_ptr<Mesh> Plane() {
    std::vector<Vertex> v;
    std::vector<unsigned> i;
    Face(v, i, Vec3(0, 1, 0), Vec3(1, 0, 0), Vec3(0, 0, -1));
    // الوجه ينزاح 0.5 على Y في Face؛ نعيده إلى y = 0
    for (auto& vert : v) vert.py -= 0.5f;
    return std::make_unique<Mesh>(v, i);
}

std::unique_ptr<Mesh> Quad() {
    std::vector<Vertex> v;
    std::vector<unsigned> i;
    Face(v, i, Vec3(0, 0, 1), Vec3(1, 0, 0), Vec3(0, 1, 0));
    for (auto& vert : v) vert.pz -= 0.5f;
    return std::make_unique<Mesh>(v, i);
}

std::unique_ptr<Mesh> Sphere() {
    const int stacks = 16, sectors = 32;
    std::vector<Vertex> v;
    std::vector<unsigned> idx;
    for (int i = 0; i <= stacks; ++i) {
        float theta = kPi * static_cast<float>(i) / stacks;
        for (int j = 0; j <= sectors; ++j) {
            float phi = 2.0f * kPi * static_cast<float>(j) / sectors;
            Vec3 n(std::sin(theta) * std::cos(phi), std::cos(theta), std::sin(theta) * std::sin(phi));
            v.push_back({n.x * 0.5f, n.y * 0.5f, n.z * 0.5f, n.x, n.y, n.z, static_cast<float>(j) / sectors,
                         1.0f - static_cast<float>(i) / stacks});
        }
    }
    for (int i = 0; i < stacks; ++i)
        for (int j = 0; j < sectors; ++j) {
            unsigned a = static_cast<unsigned>(i * (sectors + 1) + j);
            unsigned b = a + sectors + 1;
            idx.insert(idx.end(), {a, a + 1, b, a + 1, b + 1, b});
        }
    return std::make_unique<Mesh>(v, idx);
}

std::unique_ptr<Mesh> Cylinder() {
    const int sectors = 32;
    std::vector<Vertex> v;
    std::vector<unsigned> idx;
    // الجانب
    for (int j = 0; j <= sectors; ++j) {
        float phi = 2.0f * kPi * static_cast<float>(j) / sectors;
        float c = std::cos(phi), s = std::sin(phi);
        float u = static_cast<float>(j) / sectors;
        v.push_back({c * 0.5f, 0.5f, s * 0.5f, c, 0, s, u, 1});
        v.push_back({c * 0.5f, -0.5f, s * 0.5f, c, 0, s, u, 0});
    }
    for (int j = 0; j < sectors; ++j) {
        unsigned t0 = static_cast<unsigned>(2 * j), b0 = t0 + 1, t1 = t0 + 2, b1 = t0 + 3;
        idx.insert(idx.end(), {t0, t1, b0, t1, b1, b0});
    }
    // الغطاءان
    for (int cap = 0; cap < 2; ++cap) {
        float y = cap == 0 ? 0.5f : -0.5f;
        float ny = cap == 0 ? 1.0f : -1.0f;
        unsigned center = static_cast<unsigned>(v.size());
        v.push_back({0, y, 0, 0, ny, 0, 0.5f, 0.5f});
        unsigned ring = static_cast<unsigned>(v.size());
        for (int j = 0; j <= sectors; ++j) {
            float phi = 2.0f * kPi * static_cast<float>(j) / sectors;
            float c = std::cos(phi), s = std::sin(phi);
            v.push_back({c * 0.5f, y, s * 0.5f, 0, ny, 0, c * 0.5f + 0.5f, s * 0.5f + 0.5f});
        }
        for (int j = 0; j < sectors; ++j) {
            unsigned a = ring + static_cast<unsigned>(j);
            if (cap == 0) idx.insert(idx.end(), {center, a + 1, a});
            else idx.insert(idx.end(), {center, a, a + 1});
        }
    }
    return std::make_unique<Mesh>(v, idx);
}

std::unique_ptr<LineMesh> WireCube() {
    std::vector<float> l;
    const float c[8][3] = {{-.5f, -.5f, -.5f}, {.5f, -.5f, -.5f}, {.5f, .5f, -.5f}, {-.5f, .5f, -.5f},
                           {-.5f, -.5f, .5f},  {.5f, -.5f, .5f},  {.5f, .5f, .5f},  {-.5f, .5f, .5f}};
    const int e[12][2] = {{0, 1}, {1, 2}, {2, 3}, {3, 0}, {4, 5}, {5, 6}, {6, 7}, {7, 4}, {0, 4}, {1, 5}, {2, 6}, {3, 7}};
    for (auto& ed : e)
        for (int k = 0; k < 2; ++k) l.insert(l.end(), {c[ed[k]][0], c[ed[k]][1], c[ed[k]][2]});
    return std::make_unique<LineMesh>(l);
}

std::unique_ptr<LineMesh> Grid(int half) {
    std::vector<float> l;
    float h = static_cast<float>(half);
    for (int i = -half; i <= half; ++i) {
        if (i == 0) continue;  // المحور يُرسم بلون مختلف
        float f = static_cast<float>(i);
        l.insert(l.end(), {f, 0, -h, f, 0, h});
        l.insert(l.end(), {-h, 0, f, h, 0, f});
    }
    return std::make_unique<LineMesh>(l);
}

std::unique_ptr<LineMesh> Axis(float half) {
    return std::make_unique<LineMesh>(std::vector<float>{-half, 0, 0, half, 0, 0});
}

}  // namespace MeshFactory
}  // namespace nova
