#pragma once
#include "render/GL.h"

namespace nova {

// هدف رسم خارج الشاشة (يُعرض داخل نوافذ Scene و Game)
class Framebuffer {
public:
    Framebuffer() = default;
    ~Framebuffer() { Destroy(); }
    Framebuffer(const Framebuffer&) = delete;
    Framebuffer& operator=(const Framebuffer&) = delete;

    void Resize(int w, int h);
    void Bind() const;
    void Unbind() const;
    GLuint ColorTexture() const { return color; }
    int Width() const { return width; }
    int Height() const { return height; }

private:
    void Create();
    void Destroy();
    GLuint fbo = 0, color = 0, depth = 0;
    int width = 0, height = 0;
};

}  // namespace nova
