#pragma once
#include "render/GL.h"

#include <string>

namespace nova {

struct Texture {
    GLuint id = 0;
    int width = 0, height = 0;
};

// يحمّل الصورة (png/jpg/bmp/tga) مرة واحدة ويخزنها. يعيد nullptr إذا فشل التحميل أو كان المسار فارغًا.
Texture* GetTexture(const std::string& path);

// يحذف كل الخامات المحمّلة (يُستدعى قبل تدمير سياق OpenGL)
void ReleaseTextures();

}  // namespace nova
