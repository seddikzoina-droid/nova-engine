#include "render/Shader.h"

#include "core/Log.h"

namespace nova {

// المصادر لا تحمل سطر #version؛ يُضاف هنا حسب المنصة (GLSL 330 أو GLSL ES 300)
#ifdef __ANDROID__
static const char* kGlslHeader = "#version 300 es\nprecision highp float;\nprecision highp int;\n";
#else
static const char* kGlslHeader = "#version 330 core\n";
#endif

static GLuint Compile(GLenum type, const char* src) {
    GLuint s = glCreateShader(type);
    const char* parts[2] = {kGlslHeader, src};
    glShaderSource(s, 2, parts, nullptr);
    glCompileShader(s);
    GLint ok = 0;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok) {
        char buf[2048];
        glGetShaderInfoLog(s, sizeof buf, nullptr, buf);
        Log::Error(std::string("Shader compile error: ") + buf);
    }
    return s;
}

Shader::Shader(const char* vertexSrc, const char* fragmentSrc) {
    GLuint vs = Compile(GL_VERTEX_SHADER, vertexSrc);
    GLuint fs = Compile(GL_FRAGMENT_SHADER, fragmentSrc);
    program = glCreateProgram();
    glAttachShader(program, vs);
    glAttachShader(program, fs);
    glLinkProgram(program);
    GLint ok = 0;
    glGetProgramiv(program, GL_LINK_STATUS, &ok);
    if (!ok) {
        char buf[2048];
        glGetProgramInfoLog(program, sizeof buf, nullptr, buf);
        Log::Error(std::string("Shader link error: ") + buf);
    }
    glDeleteShader(vs);
    glDeleteShader(fs);
}

Shader::~Shader() {
    if (program) glDeleteProgram(program);
}

GLint Shader::Loc(const char* name) {
    auto it = cache.find(name);
    if (it != cache.end()) return it->second;
    GLint l = glGetUniformLocation(program, name);
    cache[name] = l;
    return l;
}

void Shader::SetInt(const char* n, int v) { glUniform1i(Loc(n), v); }
void Shader::SetFloat(const char* n, float v) { glUniform1f(Loc(n), v); }
void Shader::SetVec3(const char* n, float x, float y, float z) { glUniform3f(Loc(n), x, y, z); }
void Shader::SetMat3(const char* n, const float* m) { glUniformMatrix3fv(Loc(n), 1, GL_FALSE, m); }
void Shader::SetMat4(const char* n, const float* m) { glUniformMatrix4fv(Loc(n), 1, GL_FALSE, m); }

}  // namespace nova
