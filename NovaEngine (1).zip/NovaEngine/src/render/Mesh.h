#pragma once
#include "render/GL.h"

#include <memory>
#include <vector>

namespace nova {

struct Vertex {
    float px, py, pz;
    float nx, ny, nz;
    float u, v;
};

class Mesh {
public:
    Mesh(const std::vector<Vertex>& vertices, const std::vector<unsigned>& indices);
    ~Mesh();
    Mesh(const Mesh&) = delete;
    Mesh& operator=(const Mesh&) = delete;
    void Draw() const;

private:
    GLuint vao = 0, vbo = 0, ebo = 0;
    GLsizei count = 0;
};

// خطوط فقط (للشبكة والمحاور)
class LineMesh {
public:
    explicit LineMesh(const std::vector<float>& xyz);  // كل 6 أرقام = خط واحد
    ~LineMesh();
    LineMesh(const LineMesh&) = delete;
    LineMesh& operator=(const LineMesh&) = delete;
    void Draw() const;

private:
    GLuint vao = 0, vbo = 0;
    GLsizei count = 0;
};

namespace MeshFactory {
std::unique_ptr<Mesh> Cube();      // 1×1×1
std::unique_ptr<Mesh> Sphere();    // قطر 1
std::unique_ptr<Mesh> Plane();     // 1×1 على XZ، يواجه +Y
std::unique_ptr<Mesh> Cylinder();  // قطر 1، ارتفاع 1
std::unique_ptr<Mesh> Quad();      // 1×1 على XY، يواجه +Z (للـ Sprites)
std::unique_ptr<LineMesh> WireCube();  // حواف مكعب 1×1×1
std::unique_ptr<LineMesh> Grid(int half);
std::unique_ptr<LineMesh> Axis(float half);  // خط على محور X
}  // namespace MeshFactory

}  // namespace nova
