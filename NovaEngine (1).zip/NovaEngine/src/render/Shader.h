#pragma once
#include "render/GL.h"

#include <string>
#include <unordered_map>

namespace nova {

class Shader {
public:
    Shader(const char* vertexSrc, const char* fragmentSrc);
    ~Shader();
    Shader(const Shader&) = delete;
    Shader& operator=(const Shader&) = delete;

    void Use() const { glUseProgram(program); }
    void SetInt(const char* name, int v);
    void SetFloat(const char* name, float v);
    void SetVec3(const char* name, float x, float y, float z);
    void SetMat3(const char* name, const float* m9);
    void SetMat4(const char* name, const float* m16);

private:
    GLint Loc(const char* name);
    GLuint program = 0;
    std::unordered_map<std::string, GLint> cache;
};

}  // namespace nova
