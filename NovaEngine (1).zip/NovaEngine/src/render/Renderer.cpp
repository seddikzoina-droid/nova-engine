#include "render/Renderer.h"

#include <algorithm>
#include <cstdio>

#include "render/Texture.h"

namespace nova {

namespace {

const char* kVS = R"(layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;
uniform mat4 uModel;
uniform mat4 uView;
uniform mat4 uProj;
uniform mat3 uNormalMat;
out vec3 vPos;
out vec3 vNormal;
out vec2 vUV;
void main() {
    vec4 wp = uModel * vec4(aPos, 1.0);
    vPos = wp.xyz;
    vNormal = uNormalMat * aNormal;
    vUV = aUV;
    gl_Position = uProj * uView * wp;
}
)";

const char* kLitFS = R"(in vec3 vPos;
in vec3 vNormal;
in vec2 vUV;
out vec4 FragColor;
uniform vec3 uColor;
uniform float uShininess;
uniform int uHasTex;
uniform sampler2D uTex;
uniform vec3 uCamPos;
uniform int uLightCount;
uniform int uLightType[8];
uniform vec3 uLightPos[8];
uniform vec3 uLightDir[8];
uniform vec3 uLightColor[8];
uniform float uLightRange[8];
void main() {
    vec3 base = uColor;
    float alpha = 1.0;
    if (uHasTex == 1) {
        vec4 t = texture(uTex, vUV);
        base *= t.rgb;
        alpha = t.a;
    }
    vec3 N = normalize(vNormal);
    vec3 V = normalize(uCamPos - vPos);
    if (dot(N, V) < 0.0) N = -N;
    vec3 result = base * 0.25;
    for (int i = 0; i < uLightCount; ++i) {
        vec3 L;
        float att = 1.0;
        if (uLightType[i] == 0) {
            L = normalize(-uLightDir[i]);
        } else {
            vec3 d = uLightPos[i] - vPos;
            float dist = length(d);
            L = d / max(dist, 0.0001);
            float r = max(uLightRange[i], 0.001);
            att = clamp(1.0 - (dist * dist) / (r * r), 0.0, 1.0);
            att *= att;
        }
        float diff = max(dot(N, L), 0.0);
        vec3 H = normalize(L + V);
        float spec = (diff > 0.0) ? pow(max(dot(N, H), 0.0), uShininess) : 0.0;
        result += (base * diff + vec3(0.25) * spec) * uLightColor[i] * att;
    }
    FragColor = vec4(result, alpha);
}
)";

const char* kUnlitFS = R"(in vec3 vPos;
in vec3 vNormal;
in vec2 vUV;
out vec4 FragColor;
uniform vec3 uColor;
uniform float uAlpha;
uniform int uHasTex;
uniform sampler2D uTex;
void main() {
    vec4 c = vec4(uColor, uAlpha);
    if (uHasTex == 1) c *= texture(uTex, vUV);
    FragColor = c;
}
)";

}  // namespace

Renderer::Renderer() {
    lit = std::make_unique<Shader>(kVS, kLitFS);
    unlit = std::make_unique<Shader>(kVS, kUnlitFS);
    cube = MeshFactory::Cube();
    sphere = MeshFactory::Sphere();
    plane = MeshFactory::Plane();
    cylinder = MeshFactory::Cylinder();
    quad = MeshFactory::Quad();
    grid = MeshFactory::Grid(50);
    axis = MeshFactory::Axis(50.0f);
    wireCube = MeshFactory::WireCube();
}

const Mesh& Renderer::MeshFor(MeshType t) const {
    switch (t) {
        case MeshType::Sphere: return *sphere;
        case MeshType::Plane: return *plane;
        case MeshType::Cylinder: return *cylinder;
        default: return *cube;
    }
}

void Renderer::SetModel(Shader& s, const Mat4& model) {
    s.SetMat4("uModel", model.m);
    Mat4 inv = model.Inverse();
    float n[9];  // (inverse(model)^T) للمصفوفة 3x3 العلوية، بترتيب الأعمدة
    for (int r = 0; r < 3; ++r)
        for (int c = 0; c < 3; ++c) n[c * 3 + r] = inv.m[r * 4 + c];
    s.SetMat3("uNormalMat", n);
}

void Renderer::DrawWire(const LineMesh& mesh, const Mat4& model, const Vec3& color, const Mat4& view, const Mat4& proj) {
    unlit->Use();
    unlit->SetMat4("uView", view.m);
    unlit->SetMat4("uProj", proj.m);
    SetModel(*unlit, model);
    unlit->SetVec3("uColor", color.x, color.y, color.z);
    unlit->SetFloat("uAlpha", 1.0f);
    unlit->SetInt("uHasTex", 0);
    mesh.Draw();
}

void Renderer::Render(const Scene& scene, const Mat4& view, const Mat4& proj, const Vec3& camPos,
                      const Vec3& clearColor, const Options& opt) {
    glEnable(GL_DEPTH_TEST);
    glDepthFunc(GL_LEQUAL);
    glDisable(GL_CULL_FACE);
    glEnable(GL_BLEND);
    glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
    glClearColor(clearColor.x, clearColor.y, clearColor.z, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // ---------- الشبكة والمحاور (المحرر) ----------
    if (opt.drawGrid) {
        unlit->Use();
        unlit->SetMat4("uView", view.m);
        unlit->SetMat4("uProj", proj.m);
        unlit->SetInt("uHasTex", 0);
        Mat4 gridModel = opt.grid2D ? Mat4::RotateX(90.0f) : Mat4();
        SetModel(*unlit, gridModel);
        unlit->SetVec3("uColor", 0.45f, 0.45f, 0.5f);
        unlit->SetFloat("uAlpha", 0.35f);
        grid->Draw();

        unlit->SetFloat("uAlpha", 0.9f);
        SetModel(*unlit, Mat4());
        unlit->SetVec3("uColor", 0.85f, 0.25f, 0.25f);  // X
        axis->Draw();
        if (opt.grid2D) {
            SetModel(*unlit, Mat4::RotateZ(90.0f));
            unlit->SetVec3("uColor", 0.3f, 0.8f, 0.3f);  // Y
        } else {
            SetModel(*unlit, Mat4::RotateY(90.0f));
            unlit->SetVec3("uColor", 0.3f, 0.45f, 0.9f);  // Z
        }
        axis->Draw();
    }

    // ---------- الإضاءة ----------
    struct LightData {
        int type;
        Vec3 pos, dir, color;
        float range;
    };
    std::vector<LightData> lights;
    for (auto& up : scene.Entities()) {
        const Entity& e = *up;
        if (!e.light || !scene.IsActiveInHierarchy(e) || lights.size() >= 8) continue;
        Mat4 w = scene.WorldMatrix(e);
        LightData d;
        d.type = e.light->type == LightType::Point ? 1 : 0;
        d.pos = w.TransformPoint(Vec3(0, 0, 0));
        d.dir = Normalize(w.TransformDir(Vec3(0, 0, -1)));
        d.color = e.light->color * e.light->intensity;
        d.range = e.light->range;
        lights.push_back(d);
    }
    if (lights.empty()) lights.push_back({0, Vec3(), Normalize(Vec3(-0.4f, -1.0f, -0.3f)), Vec3(0.9f), 10.0f});

    lit->Use();
    lit->SetMat4("uView", view.m);
    lit->SetMat4("uProj", proj.m);
    lit->SetVec3("uCamPos", camPos.x, camPos.y, camPos.z);
    lit->SetInt("uLightCount", static_cast<int>(lights.size()));
    for (size_t i = 0; i < lights.size(); ++i) {
        char name[48];
        std::snprintf(name, sizeof name, "uLightType[%zu]", i);
        lit->SetInt(name, lights[i].type);
        std::snprintf(name, sizeof name, "uLightPos[%zu]", i);
        lit->SetVec3(name, lights[i].pos.x, lights[i].pos.y, lights[i].pos.z);
        std::snprintf(name, sizeof name, "uLightDir[%zu]", i);
        lit->SetVec3(name, lights[i].dir.x, lights[i].dir.y, lights[i].dir.z);
        std::snprintf(name, sizeof name, "uLightColor[%zu]", i);
        lit->SetVec3(name, lights[i].color.x, lights[i].color.y, lights[i].color.z);
        std::snprintf(name, sizeof name, "uLightRange[%zu]", i);
        lit->SetFloat(name, lights[i].range);
    }

    // ---------- المجسمات 3D ----------
    for (auto& up : scene.Entities()) {
        const Entity& e = *up;
        if (!e.mesh || !scene.IsActiveInHierarchy(e)) continue;
        SetModel(*lit, scene.WorldMatrix(e));
        lit->SetVec3("uColor", e.mesh->color.x, e.mesh->color.y, e.mesh->color.z);
        lit->SetFloat("uShininess", std::max(e.mesh->shininess, 1.0f));
        Texture* tex = GetTexture(e.mesh->texture);
        if (tex) {
            glActiveTexture(GL_TEXTURE0);
            glBindTexture(GL_TEXTURE_2D, tex->id);
            lit->SetInt("uTex", 0);
        }
        lit->SetInt("uHasTex", tex ? 1 : 0);
        MeshFor(e.mesh->mesh).Draw();
    }

    // ---------- السبرايتات 2D (مرتبة من الخلف للأمام) ----------
    struct SpriteItem {
        const Entity* e;
        Mat4 world;
        float dist;
    };
    std::vector<SpriteItem> sprites;
    for (auto& up : scene.Entities()) {
        const Entity& e = *up;
        if (!e.sprite || !scene.IsActiveInHierarchy(e)) continue;
        Mat4 w = scene.WorldMatrix(e);
        if (e.sprite->flipX) w = w * Mat4::Scale(Vec3(-1, 1, 1));
        sprites.push_back({&e, w, Length(w.TransformPoint(Vec3(0, 0, 0)) - camPos)});
    }
    std::stable_sort(sprites.begin(), sprites.end(), [](const SpriteItem& a, const SpriteItem& b) {
        if (a.e->sprite->sortingOrder != b.e->sprite->sortingOrder)
            return a.e->sprite->sortingOrder < b.e->sprite->sortingOrder;
        return a.dist > b.dist;
    });
    if (!sprites.empty()) {
        unlit->Use();
        unlit->SetMat4("uView", view.m);
        unlit->SetMat4("uProj", proj.m);
        glDepthMask(GL_FALSE);
        for (auto& s : sprites) {
            SetModel(*unlit, s.world);
            const auto& sp = *s.e->sprite;
            unlit->SetVec3("uColor", sp.color.x, sp.color.y, sp.color.z);
            unlit->SetFloat("uAlpha", 1.0f);
            Texture* tex = GetTexture(sp.texture);
            if (tex) {
                glActiveTexture(GL_TEXTURE0);
                glBindTexture(GL_TEXTURE_2D, tex->id);
                unlit->SetInt("uTex", 0);
            }
            unlit->SetInt("uHasTex", tex ? 1 : 0);
            quad->Draw();
        }
        glDepthMask(GL_TRUE);
    }

    // ---------- طبقة المحرر: أيقونات + إطار التحديد + صندوق التصادم ----------
    if (opt.editorGizmos) {
        glDisable(GL_DEPTH_TEST);
        for (auto& up : scene.Entities()) {
            const Entity& e = *up;
            if (e.mesh || e.sprite || !scene.IsActiveInHierarchy(e)) continue;
            Vec3 p = scene.WorldMatrix(e).TransformPoint(Vec3(0, 0, 0));
            Vec3 col = e.light ? Vec3(1.0f, 0.9f, 0.3f) : (e.camera ? Vec3(0.3f, 0.9f, 0.9f) : Vec3(0.7f));
            DrawWire(*wireCube, Mat4::Translate(p) * Mat4::Scale(Vec3(0.6f)), col, view, proj);
        }
        if (const Entity* sel = scene.Find(opt.selected)) {
            Mat4 w = scene.WorldMatrix(*sel);
            const Vec3 orange(1.0f, 0.55f, 0.1f);
            // إطار التحديد = صندوق الحدود (كل المجسمات داخل مكعب 1×1×1، والمستوى والسبرايت رقيقان)
            if (sel->mesh) {
                Mat4 b = sel->mesh->mesh == MeshType::Plane ? w * Mat4::Scale(Vec3(1, 0.02f, 1)) : w;
                DrawWire(*wireCube, b, orange, view, proj);
            } else if (sel->sprite) {
                DrawWire(*wireCube, w * Mat4::Scale(Vec3(1, 1, 0.02f)), orange, view, proj);
            }
            if (sel->collider) {
                Mat4 cm = w * Mat4::Translate(sel->collider->center) * Mat4::Scale(sel->collider->size);
                DrawWire(*wireCube, cm, Vec3(0.3f, 1.0f, 0.4f), view, proj);
            }
        }
        glEnable(GL_DEPTH_TEST);
    }
}

}  // namespace nova
