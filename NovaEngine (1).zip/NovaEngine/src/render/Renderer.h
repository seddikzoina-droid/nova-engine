#pragma once
#include <memory>

#include "render/Mesh.h"
#include "render/Shader.h"
#include "scene/Scene.h"

namespace nova {

class Renderer {
public:
    struct Options {
        bool drawGrid = false;       // شبكة الأرضية (المحرر فقط)
        bool grid2D = false;         // الشبكة على المستوى XY بدل XZ
        bool editorGizmos = false;   // أيقونات الإضاءة والكاميرا والكائنات الفارغة
        EntityId selected = 0;       // الكائن المحدد (يُرسم له إطار)
    };

    Renderer();

    // يرسم المشهد في الإطار (Framebuffer) المربوط حاليًا
    void Render(const Scene& scene, const Mat4& view, const Mat4& proj, const Vec3& camPos, const Vec3& clearColor,
                const Options& opt);

private:
    const Mesh& MeshFor(MeshType t) const;
    void SetModel(Shader& s, const Mat4& model);
    void DrawWire(const LineMesh& mesh, const Mat4& model, const Vec3& color, const Mat4& view, const Mat4& proj);

    std::unique_ptr<Shader> lit, unlit;
    std::unique_ptr<Mesh> cube, sphere, plane, cylinder, quad;
    std::unique_ptr<LineMesh> grid, axis, wireCube;
};

}  // namespace nova
