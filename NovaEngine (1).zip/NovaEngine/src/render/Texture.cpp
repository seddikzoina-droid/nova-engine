#include "render/Texture.h"

#include <memory>
#include <unordered_map>

#include "core/Log.h"

#define STB_IMAGE_IMPLEMENTATION
#include <stb_image.h>

namespace nova {

static std::unordered_map<std::string, std::unique_ptr<Texture>>& Cache() {
    static std::unordered_map<std::string, std::unique_ptr<Texture>> cache;
    return cache;
}

void ReleaseTextures() {
    for (auto& kv : Cache())
        if (kv.second && kv.second->id) glDeleteTextures(1, &kv.second->id);
    Cache().clear();
}

Texture* GetTexture(const std::string& path) {
    if (path.empty()) return nullptr;
    auto& cache = Cache();
    auto it = cache.find(path);
    if (it != cache.end()) return it->second.get();

    stbi_set_flip_vertically_on_load(1);
    int w = 0, h = 0, n = 0;
    unsigned char* data = stbi_load(path.c_str(), &w, &h, &n, 4);
    if (!data) {
        Log::Error("Cannot load texture: " + path);
        cache[path] = nullptr;
        return nullptr;
    }
    auto tex = std::make_unique<Texture>();
    tex->width = w;
    tex->height = h;
    glGenTextures(1, &tex->id);
    glBindTexture(GL_TEXTURE_2D, tex->id);
    glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, w, h, 0, GL_RGBA, GL_UNSIGNED_BYTE, data);
    glGenerateMipmap(GL_TEXTURE_2D);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    stbi_image_free(data);
    Log::Info("Loaded texture: " + path + " (" + std::to_string(w) + "x" + std::to_string(h) + ")");
    Texture* raw = tex.get();
    cache[path] = std::move(tex);
    return raw;
}

}  // namespace nova
