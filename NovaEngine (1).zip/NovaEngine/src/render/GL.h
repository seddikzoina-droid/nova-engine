#pragma once
// ترويسة OpenGL موحّدة: سطح المكتب = OpenGL 3.3 عبر GLEW، أندرويد = OpenGL ES 3.0
#ifdef __ANDROID__
#include <GLES3/gl3.h>
#else
#include <GL/glew.h>
#endif
