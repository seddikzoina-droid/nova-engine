#pragma once
// واجهة صغيرة تعزل المحرر عن نظام التشغيل (سطح المكتب عبر GLFW، أندرويد عبر NativeActivity)
#include <chrono>

namespace nova {
namespace Platform {

// الزمن بالثواني منذ أول استدعاء
inline double Time() {
    using Clock = std::chrono::steady_clock;
    static const Clock::time_point t0 = Clock::now();
    return std::chrono::duration<double>(Clock::now() - t0).count();
}

void RequestQuit();        // يطلب إغلاق التطبيق
bool IsMobile();           // true على أندرويد: واجهة لمس بتبويبات
const char* DataDir();     // مجلد ملفات المستخدم (assets/ والمشاهد). فارغ على سطح المكتب

}  // namespace Platform
}  // namespace nova
