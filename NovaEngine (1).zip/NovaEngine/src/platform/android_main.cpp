// نقطة دخول أندرويد: NativeActivity + EGL (OpenGL ES 3.0) + Dear ImGui
// مبنية على المثال الرسمي example_android_opengl3 من ImGui، مع تشغيل محرر Nova وتتبع اللمس المتعدد.
#include <EGL/egl.h>
#include <GLES3/gl3.h>
#include <android/asset_manager.h>
#include <android/configuration.h>
#include <android/input.h>
#include <android/log.h>
#include <android/native_window.h>
#include <android_native_app_glue.h>
#include <sys/stat.h>
#include <unistd.h>

#include <algorithm>
#include <cstdio>
#include <memory>
#include <string>

#include <imgui.h>
#include <imgui_impl_android.h>
#include <imgui_impl_opengl3.h>
#include <ImGuizmo.h>  // يجب أن يأتي بعد imgui.h

#include "core/Touch.h"
#include "editor/Editor.h"
#include "platform/Platform.h"

#ifndef EGL_OPENGL_ES3_BIT
#define EGL_OPENGL_ES3_BIT 0x0040
#endif

static const char* kTag = "NovaEngine";

// ---------------------------------------------------------------- Platform

namespace nova {
namespace Platform {
static std::string g_dataDir;
static android_app* g_platformApp = nullptr;

void RequestQuit() {
    if (g_platformApp) ANativeActivity_finish(g_platformApp->activity);
}
bool IsMobile() { return true; }
const char* DataDir() { return g_dataDir.c_str(); }
}  // namespace Platform
}  // namespace nova

// ---------------------------------------------------------------- الحالة العامة

static EGLDisplay g_EglDisplay = EGL_NO_DISPLAY;
static EGLSurface g_EglSurface = EGL_NO_SURFACE;
static EGLContext g_EglContext = EGL_NO_CONTEXT;
static android_app* g_App = nullptr;
static bool g_Initialized = false;
static std::unique_ptr<nova::Editor> g_Editor;
static double g_LastTime = 0.0;

// JNI: يُربط الخيط مرة واحدة ويبقى مربوطًا حتى نهاية التطبيق
static JNIEnv* g_Env = nullptr;
static jmethodID g_ShowKb = nullptr, g_HideKb = nullptr, g_PollChar = nullptr;

static void Init(android_app* app);
static void Shutdown();
static void MainLoopStep();

// ---------------------------------------------------------------- JNI helpers

static void SetupJni() {
    JavaVM* vm = g_App->activity->vm;
    if (vm->GetEnv(reinterpret_cast<void**>(&g_Env), JNI_VERSION_1_6) != JNI_OK) {
        if (vm->AttachCurrentThread(&g_Env, nullptr) != JNI_OK) g_Env = nullptr;
    }
    if (!g_Env) return;
    jclass cls = g_Env->GetObjectClass(g_App->activity->clazz);
    g_ShowKb = g_Env->GetMethodID(cls, "showSoftInput", "()V");
    g_HideKb = g_Env->GetMethodID(cls, "hideSoftInput", "()V");
    g_PollChar = g_Env->GetMethodID(cls, "pollUnicodeChar", "()I");
}

static void ShowSoftKeyboard() {
    if (g_Env && g_ShowKb) g_Env->CallVoidMethod(g_App->activity->clazz, g_ShowKb);
}
static void HideSoftKeyboard() {
    if (g_Env && g_HideKb) g_Env->CallVoidMethod(g_App->activity->clazz, g_HideKb);
}
// الأحرف المكتوبة بلوحة المفاتيح الافتراضية تصل عبر MainActivity ثم تُمرَّر إلى ImGui
static void PollUnicodeChars() {
    if (!g_Env || !g_PollChar) return;
    ImGuiIO& io = ImGui::GetIO();
    jint ch;
    while ((ch = g_Env->CallIntMethod(g_App->activity->clazz, g_PollChar)) != 0) io.AddInputCharacter(static_cast<unsigned>(ch));
}

// ---------------------------------------------------------------- ملفات المستخدم

static bool FileExists(const std::string& p) {
    struct stat st;
    return stat(p.c_str(), &st) == 0;
}

// ينسخ مشاهد وصور المشروع المرفقة داخل الـ APK إلى assets/ في مجلد التطبيق (دون الكتابة فوق ملفات المستخدم)
static void CopyBundledAssets(android_app* app) {
    mkdir("assets", 0755);
    AAssetManager* mgr = app->activity->assetManager;
    AAssetDir* dir = AAssetManager_openDir(mgr, "");
    if (!dir) return;
    const char* name;
    while ((name = AAssetDir_getNextFileName(dir)) != nullptr) {
        std::string dst = std::string("assets/") + name;
        if (FileExists(dst)) continue;
        AAsset* a = AAssetManager_open(mgr, name, AASSET_MODE_STREAMING);
        if (!a) continue;
        FILE* f = std::fopen(dst.c_str(), "wb");
        if (f) {
            char buf[8192];
            int n;
            while ((n = AAsset_read(a, buf, sizeof buf)) > 0) std::fwrite(buf, 1, static_cast<size_t>(n), f);
            std::fclose(f);
        }
        AAsset_close(a);
    }
    AAssetDir_close(dir);
}

// ---------------------------------------------------------------- الأحداث

static void UpdateTouch(AInputEvent* e) {
    if (AInputEvent_getType(e) != AINPUT_EVENT_TYPE_MOTION) return;
    int32_t action = AMotionEvent_getAction(e);
    int32_t masked = action & AMOTION_EVENT_ACTION_MASK;
    int32_t idx = (action & AMOTION_EVENT_ACTION_POINTER_INDEX_MASK) >> AMOTION_EVENT_ACTION_POINTER_INDEX_SHIFT;
    nova::Touch& t = nova::Touch::State();
    if (masked == AMOTION_EVENT_ACTION_CANCEL) {
        t.count = 0;
        return;
    }
    bool lifting = masked == AMOTION_EVENT_ACTION_UP || masked == AMOTION_EVENT_ACTION_POINTER_UP;
    size_t n = AMotionEvent_getPointerCount(e);
    int c = 0;
    for (size_t i = 0; i < n && c < nova::Touch::kMax; ++i) {
        if (lifting && static_cast<int32_t>(i) == idx) continue;  // هذا الإصبع يُرفع الآن
        t.x[c] = AMotionEvent_getX(e, i);
        t.y[c] = AMotionEvent_getY(e, i);
        ++c;
    }
    t.count = c;
}

static int32_t HandleInputEvent(android_app* app, AInputEvent* e) {
    UpdateTouch(e);
    return ImGui_ImplAndroid_HandleInputEvent(e);
}

static void HandleAppCmd(android_app* app, int32_t cmd) {
    switch (cmd) {
        case APP_CMD_INIT_WINDOW: Init(app); break;
        case APP_CMD_TERM_WINDOW: Shutdown(); break;
        case APP_CMD_PAUSE:
            if (g_Editor) g_Editor->SaveSession();
            break;
        default: break;
    }
}

void android_main(android_app* app) {
    g_App = app;
    nova::Platform::g_platformApp = app;
    app->onAppCmd = HandleAppCmd;
    app->onInputEvent = HandleInputEvent;

    // مجلد المستخدم: التخزين الخارجي الخاص بالتطبيق (يمكن فتحه من مدير الملفات) أو الداخلي
    const char* dir = app->activity->externalDataPath ? app->activity->externalDataPath : app->activity->internalDataPath;
    nova::Platform::g_dataDir = dir ? dir : "";
    if (!nova::Platform::g_dataDir.empty() && chdir(nova::Platform::g_dataDir.c_str()) != 0)
        __android_log_print(ANDROID_LOG_ERROR, kTag, "chdir failed: %s", nova::Platform::g_dataDir.c_str());
    CopyBundledAssets(app);
    SetupJni();

    while (true) {
        int events;
        android_poll_source* source;
        // إذا كان التطبيق غير ظاهر تنتظر هذه الحلقة حتى تهيئة النافذة (g_Initialized)
        while (ALooper_pollOnce(g_Initialized ? 0 : -1, nullptr, &events, reinterpret_cast<void**>(&source)) >= 0) {
            if (source) source->process(app, source);
            if (app->destroyRequested != 0) {
                if (g_Initialized) Shutdown();
                if (g_Env) app->activity->vm->DetachCurrentThread();
                return;
            }
        }
        MainLoopStep();
    }
}

// ---------------------------------------------------------------- تهيئة

static void Init(android_app* app) {
    if (g_Initialized) return;
    g_App = app;
    ANativeWindow_acquire(app->window);

    g_EglDisplay = eglGetDisplay(EGL_DEFAULT_DISPLAY);
    if (g_EglDisplay == EGL_NO_DISPLAY) __android_log_print(ANDROID_LOG_ERROR, kTag, "eglGetDisplay failed");
    if (eglInitialize(g_EglDisplay, nullptr, nullptr) != EGL_TRUE)
        __android_log_print(ANDROID_LOG_ERROR, kTag, "eglInitialize failed");

    const EGLint attrs[] = {EGL_RENDERABLE_TYPE, EGL_OPENGL_ES3_BIT, EGL_BLUE_SIZE, 8,  EGL_GREEN_SIZE, 8,
                            EGL_RED_SIZE,        8,                  EGL_DEPTH_SIZE, 24, EGL_SURFACE_TYPE, EGL_WINDOW_BIT,
                            EGL_NONE};
    EGLConfig config = nullptr;
    EGLint numConfigs = 0;
    if (eglChooseConfig(g_EglDisplay, attrs, &config, 1, &numConfigs) != EGL_TRUE || numConfigs == 0)
        __android_log_print(ANDROID_LOG_ERROR, kTag, "eglChooseConfig found no OpenGL ES 3 config");
    EGLint format = 0;
    eglGetConfigAttrib(g_EglDisplay, config, EGL_NATIVE_VISUAL_ID, &format);
    ANativeWindow_setBuffersGeometry(app->window, 0, 0, format);

    const EGLint ctxAttrs[] = {EGL_CONTEXT_CLIENT_VERSION, 3, EGL_NONE};
    g_EglContext = eglCreateContext(g_EglDisplay, config, EGL_NO_CONTEXT, ctxAttrs);
    if (g_EglContext == EGL_NO_CONTEXT) __android_log_print(ANDROID_LOG_ERROR, kTag, "eglCreateContext failed");
    g_EglSurface = eglCreateWindowSurface(g_EglDisplay, config, app->window, nullptr);
    eglMakeCurrent(g_EglDisplay, g_EglSurface, g_EglSurface, g_EglContext);

    // Dear ImGui
    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.IniFilename = nullptr;  // لا حاجة لحفظ التخطيط: الواجهة تبويبات ثابتة

    ImGuiStyle& style = ImGui::GetStyle();
    ImGui::StyleColorsDark();
    style.FrameRounding = 4.0f;
    style.GrabRounding = 4.0f;
    style.ItemSpacing = ImVec2(8, 9);
    style.TouchExtraPadding = ImVec2(6, 6);

    ImGui_ImplAndroid_Init(app->window);
    ImGui_ImplOpenGL3_Init("#version 300 es");

    // مقياس الواجهة من كثافة الشاشة (160 dpi = 1.0)
    int density = app->config ? AConfiguration_getDensity(app->config) : 0;
    float dpi = (density > 0 && density < 2000) ? static_cast<float>(density) : 320.0f;
    float scale = std::max(1.5f, std::min(3.5f, dpi / 160.0f));
    style.ScaleAllSizes(scale);
    style.FontScaleDpi = scale;

    g_Editor = std::make_unique<nova::Editor>();
    g_LastTime = nova::Platform::Time();
    g_Initialized = true;
}

static void Shutdown() {
    if (!g_Initialized) return;
    if (g_Editor) {
        g_Editor->SaveSession();  // سياق GL سيُدمَّر: نحفظ عملك ثم نعيد بناء المحرر عند العودة
        g_Editor.reset();         // يحذف موارد GL والخامات والسياق ما زال حيًا
    }
    ImGui_ImplOpenGL3_Shutdown();
    ImGui_ImplAndroid_Shutdown();
    ImGui::DestroyContext();

    if (g_EglDisplay != EGL_NO_DISPLAY) {
        eglMakeCurrent(g_EglDisplay, EGL_NO_SURFACE, EGL_NO_SURFACE, EGL_NO_CONTEXT);
        if (g_EglContext != EGL_NO_CONTEXT) eglDestroyContext(g_EglDisplay, g_EglContext);
        if (g_EglSurface != EGL_NO_SURFACE) eglDestroySurface(g_EglDisplay, g_EglSurface);
        eglTerminate(g_EglDisplay);
    }
    g_EglDisplay = EGL_NO_DISPLAY;
    g_EglContext = EGL_NO_CONTEXT;
    g_EglSurface = EGL_NO_SURFACE;
    ANativeWindow_release(g_App->window);
    nova::Touch::State().count = 0;
    g_Initialized = false;
}

// ---------------------------------------------------------------- الحلقة

static void MainLoopStep() {
    if (g_EglDisplay == EGL_NO_DISPLAY || !g_Editor) return;
    ImGuiIO& io = ImGui::GetIO();

    PollUnicodeChars();
    static bool wantTextLast = false;
    if (io.WantTextInput && !wantTextLast) ShowSoftKeyboard();
    if (!io.WantTextInput && wantTextLast) HideSoftKeyboard();
    wantTextLast = io.WantTextInput;

    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame();
    ImGui::NewFrame();
    ImGuizmo::BeginFrame();

    double now = nova::Platform::Time();
    float dt = static_cast<float>(now - g_LastTime);
    g_LastTime = now;
    g_Editor->Frame(std::min(dt, 0.1f));

    ImGui::Render();
    glViewport(0, 0, static_cast<int>(io.DisplaySize.x), static_cast<int>(io.DisplaySize.y));
    glClearColor(0.08f, 0.08f, 0.09f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT);
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    eglSwapBuffers(g_EglDisplay, g_EglSurface);
}
