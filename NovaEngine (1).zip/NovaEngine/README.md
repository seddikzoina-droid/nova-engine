# Nova Engine

محرك ألعاب 2D/3D بلغة C++17 مع محرر بواجهة رسومية (OpenGL 3.3 + Dear ImGui docking).

## ما الذي يتضمنه

| الميزة | التفاصيل |
|---|---|
| المشهد | كائنات (Entities) بتسلسل هرمي (أب/أبناء)، سحب وإفلات في Hierarchy |
| المكونات | Mesh Renderer، Sprite Renderer (2D)، Light (Directional/Point)، Camera (3D/Orthographic)، Rigid Body، Box Collider، Scripts |
| العرض | إضاءة Blinn-Phong حتى 8 أضواء، خامات (png/jpg/bmp/tga)، ترتيب السبرايتات للـ 2D |
| الفيزياء | جاذبية + تصادم AABB (Freeze Z للألعاب 2D) |
| المحرر | نوافذ قابلة للسحب والتثبيت: Hierarchy / Inspector / Scene / Game / Console / Assets |
| أدوات | Gizmos للنقل والتدوير والتكبير (ImGuizmo)، التقاط بالنقر، Undo/Redo، نسخ، حذف |
| التشغيل | Play / Pause / Stop، والمشهد يعود كما كان عند الإيقاف |
| الحفظ | ملفات `.nova` نصية قابلة للقراءة (File > Save / Open) |
| السكربتات | صنف C++ يرث من `Script` + سطر تسجيل، فيظهر في Add Component وتُعرض حقوله في Inspector |

## البناء

المتطلبات: CMake 3.20+، مترجم C++17، اتصال بالإنترنت عند أول Configure (يُنزّل GLFW و GLEW و ImGui و ImGuizmo و stb تلقائيًا).

```bash
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release -j
./bin/NovaEditor        # شغّله من جذر المشروع (حيث مجلد assets)
```

- Windows: يعمل مع Visual Studio أو MinGW (أمر CMake نفسه).
- Linux: ثبّت `libgl1-mesa-dev` و `xorg-dev` (أو `libwayland-dev libxkbcommon-dev` لـ Wayland).
- اختبار النواة فقط بدون واجهة ولا تنزيلات: `cmake -S . -B build-core -DNOVA_CORE_ONLY=ON && cmake --build build-core && ./build-core/nova_core_test`

## أندرويد (المحرر كاملًا على الهاتف)

نفس المحرر يعمل على الهاتف (OpenGL ES 3.0 عبر NativeActivity) بواجهة لمس: تبويبات سفلية بدل النوافذ المثبّتة.

**مهم:** مشروع أندرويد في مجلد `android/` (Gradle + NDK + CMake). لا يُبنى من ملفات سطح المكتب مباشرة، ولا يعمل تطبيق مثل A-IDE إذا لم يفهم مشاريع NDK (رسالة "No Android application module was found" تعني أنه لم يجد وحدة أندرويد). الطرق المضمونة للبناء:

1. **GitHub Actions (من الهاتف نفسه، بلا حاسوب):** أنشئ مستودعًا على GitHub وارفع محتوى هذا المجلد كما هو، افتح تبويب **Actions** ثم شغّل **Build Android APK** (ملف `.github/workflows/android.yml`)، وبعد دقائق نزّل `NovaEngine-debug-apk` من الـ Artifacts وثبّته (فعّل "التثبيت من مصادر غير معروفة").
2. **Android Studio على حاسوب:** افتح مجلد `android/` ثم Run (يحتاج SDK و NDK و CMake من SDK Manager).
3. سطر الأوامر (JDK 17 + Android SDK + Gradle 8.9): `gradle -p android assembleDebug` والناتج في `android/app/build/outputs/apk/debug/`.

المتطلبات: أندرويد 8.0 فما فوق، معمارية arm64 (غيّر `abiFilters` في `android/app/build.gradle` لأجهزة أخرى). الشاشة أفقية افتراضيًا (`screenOrientation` في `AndroidManifest.xml`).

**الاستخدام على الهاتف:**
- التبويبات السفلية: Scene / Game / Hierarchy / Inspector / Assets / Console.
- **Scene:** لمسة واحدة = تحديد كائن، سحب الأسهم (gizmo) = تعديل. اختر Move/Rotate/Scale من الأعلى. فعّل **Look** ليدير إصبع واحد الكاميرا. بإصبعين: تقريب/تبعيد الأصابع = تحريك الكاميرا للأمام/الخلف، وسحب الإصبعين = إزاحة جانبية (في وضع 2D: تكبير/تصغير وإزاحة).
- **Hierarchy:** أزرار + Add / Copy / Delete / Edit، واسحب كائنًا فوق آخر ليصبح ابنًا له.
- **Inspector:** اضغط على حقل رقمي لكتابة قيمة، أو اسحب لتغييرها. زر **Pick** بجانب Texture لاختيار صورة.
- **Play:** يفتح تبويب Game مع عصا تحكم افتراضية (يسار) وزر **Jump** (يمين)، ويعملان معًا بإصبعين.
- الحفظ التلقائي: عند الخروج من التطبيق يُحفظ عملك ويُستعاد تلقائيًا. للحفظ باسم استخدم File > Save As.
- ملفاتك (مشاهد `.nova` وصور) في مجلد التطبيق: `Android/data/com.nova.engine/files/assets` (يظهر مساره في تبويب Assets). ضع صورك فيه من مدير الملفات.

## الاستخدام (سطح المكتب)

- **Scene**: كليك أيمن + WASD/QE للطيران، العجلة للتقريب، `F` للتركيز على المحدد، `W/E/R` لتبديل الأداة. مفتاح **2D** يحوّل العرض لثنائي الأبعاد.
- **Play**: اضغط Play ثم انقر داخل نافذة Game واستخدم WASD/الأسهم والمسافة.
- **Ctrl+S** حفظ، **Ctrl+Z / Ctrl+Y** تراجع/إعادة، **Ctrl+D** نسخ، **Del** حذف.
- افتح `assets/demo_2d.nova` من نافذة Assets (نقر مزدوج) لتجربة لعبة منصات 2D.
- اسحب صورة من Assets إلى حقل Texture في Inspector.

## كتابة سكربت

```cpp
// src/scene/Scripts.cpp (أو أي ملف .cpp جديد أضفه إلى CORE_SOURCES في CMakeLists.txt)
class Bouncer : public Script {
public:
    float height = 2, speed = 1;
    Bouncer() { Expose("height", height); Expose("speed", speed); }  // تظهر في Inspector وتُحفظ
    const char* TypeName() const override { return "Bouncer"; }
    void OnStart() override { baseY = entity->transform.position.y; }
    void OnUpdate(float dt) override {
        t += dt * speed;
        entity->transform.position.y = baseY + std::abs(std::sin(t)) * height;
    }
private:
    float baseY = 0, t = 0;
};
NOVA_REGISTER_SCRIPT(Bouncer)
```

الحقول المكشوفة من نوع `float` فقط حاليًا (استخدم 0/1 للقيم المنطقية). يمكن للسكربت الوصول إلى `scene->FindByName("...")` و `Input::GetKey(Key::Space)`.

## هيكل المشروع

```
src/core/     رياضيات (Vec3/Mat4)، سجل الرسائل، الإدخال
src/scene/    Entity/Components، Scene (هرمية، فيزياء، حفظ/تحميل)، نظام السكربتات
src/render/   Shader، Mesh، Texture، Framebuffer، Renderer
src/editor/   واجهة المحرر (ImGui)
tests/        اختبارات النواة
assets/       صور ومشاهد (.nova)
```

## حدود معروفة (النسخة 0.1)

- لا صوت، ولا رسوم متحركة (animation)، ولا نماذج 3D خارجية (obj/gltf) بعد.
- الفيزياء مبسطة: صناديق محاذية للمحاور فقط (AABB)، بلا تدوير ولا تصادم بين جسمين ديناميكيين.
- السكربتات تُترجم مع المحرر (C++ ثابت) ولا تُحمَّل أثناء التشغيل.
- لم يُشغَّل المحرر الرسومي (سطح المكتب ولا أندرويد) داخل بيئة العمل هنا (لا شاشة ولا جهاز). النواة اختُبرت وشُغّلت، وأما المحرر والعرض وكود أندرويد فتم التحقق من ترجمتها فقط، وحزمة الـ APK لم تُبنَ هنا. إن ظهر خطأ عند أول بناء أو تشغيل فأرسله لتصحيحه.
- على أندرويد: إطار التحديد يظهر كصندوق حدود (لا يوجد وضع Wireframe في OpenGL ES)، وحقول السكربت العشرية فقط.

## الخطوات التالية المقترحة

نماذج 3D (glTF)، صوت (miniaudio)، رسوم متحركة للسبرايتات، تصادمات أدق، بناء اللعبة كملف تنفيذي مستقل (Player) بدون المحرر.
